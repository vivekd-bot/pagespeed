@echo off
title Page Speed Report & SEO Semrush Analyzer
cd /d "%~dp0"
echo =========================================================
echo   Starting Page Speed Report & SEO Semrush Analyzer...
echo =========================================================
start http://localhost:3050
node server.js
pause

