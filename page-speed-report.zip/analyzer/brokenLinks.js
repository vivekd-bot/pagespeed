const https = require('https');
const http = require('http');
const { URL } = require('url');
const cheerio = require('cheerio');
const ExcelJS = require('exceljs');
const { validateSafeUrl } = require('./security');

/**
 * Fetch a webpage and return HTML body + status code
 */
async function fetchHtml(targetUrl, timeoutMs = 12000) {
  try {
    const res = await fetch(targetUrl, {
      signal: AbortSignal.timeout(timeoutMs),
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 PageSpeedChecker/2.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });
    const body = await res.text();
    return {
      statusCode: res.status,
      body,
      finalUrl: res.url || targetUrl
    };
  } catch (err) {
    return {
      statusCode: 0,
      body: '',
      error: err.name === 'TimeoutError' ? 'Page Timeout' : (err.message || 'Fetch Error')
    };
  }
}

/**
 * Fast ping to check URL status.
 * Uses HEAD first; falls back to GET if HEAD fails (403/405).
 */
async function verifyLinkStatus(targetUrl, timeoutMs = 8000) {
  const startTime = Date.now();
  const check = validateSafeUrl(targetUrl);
  if (!check.safe) {
    return {
      targetUrl,
      statusCode: 0,
      statusCategory: 'broken',
      errorReason: check.error,
      durationMs: 0,
      finalUrl: targetUrl
    };
  }
  const parsed = check.parsed;

  try {
    let res = await fetch(targetUrl, {
      method: 'HEAD',
      signal: AbortSignal.timeout(timeoutMs),
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 PageSpeedChecker/2.0',
        'Accept': '*/*'
      }
    });

    // If server disallows HEAD (405 or 403), retry with GET
    if (res.status === 405 || res.status === 403) {
      res = await fetch(targetUrl, {
        method: 'GET',
        signal: AbortSignal.timeout(timeoutMs),
        redirect: 'follow',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 PageSpeedChecker/2.0',
          'Accept': '*/*'
        }
      });
    }

    const durationMs = Date.now() - startTime;
    const statusCode = res.status;
    const finalUrl = res.url || targetUrl;
    const redirected = res.redirected;

    let statusCategory = 'ok';
    let errorReason = 'OK';

    if (statusCode >= 400 && statusCode < 500) {
      statusCategory = 'broken';
      errorReason = statusCode === 404 ? '404 Not Found' : `${statusCode} Client Error`;
    } else if (statusCode >= 500) {
      statusCategory = 'broken';
      errorReason = `${statusCode} Server Error`;
    } else if (redirected) {
      statusCategory = 'redirect';
      errorReason = `Redirected to ${finalUrl}`;
    }

    return {
      targetUrl,
      statusCode,
      statusCategory,
      errorReason,
      durationMs,
      finalUrl
    };
  } catch (err) {
    const durationMs = Date.now() - startTime;
    let reason = err.message || 'Network Error';
    if (err.name === 'TimeoutError') {
      reason = `Timeout after ${Math.round(timeoutMs / 1000)}s`;
    } else if (err.cause?.code === 'ENOTFOUND') {
      reason = 'DNS Unresolved (Domain not found)';
    } else if (err.cause?.code === 'ECONNREFUSED') {
      reason = 'Connection Refused';
    } else if (err.cause?.code?.includes('CERT') || err.message?.includes('certificate')) {
      reason = 'SSL/TLS Certificate Error';
    }

    return {
      targetUrl,
      statusCode: err.name === 'TimeoutError' ? 408 : 0,
      statusCategory: 'broken',
      errorReason: reason,
      durationMs,
      finalUrl: targetUrl
    };
  }
}

/**
 * Extract all valid links from HTML
 */
function extractLinksFromHtml(html, pageUrl) {
  const $ = cheerio.load(html || '');
  const links = [];
  let baseHostname = '';
  try {
    baseHostname = new URL(pageUrl).hostname;
  } catch (e) {}

  $('a[href]').each((_, el) => {
    const rawHref = ($(el).attr('href') || '').trim();
    if (!rawHref) return;

    // Ignore non-http links
    if (
      rawHref.startsWith('#') ||
      rawHref.startsWith('javascript:') ||
      rawHref.startsWith('mailto:') ||
      rawHref.startsWith('tel:') ||
      rawHref.startsWith('sms:') ||
      rawHref.startsWith('whatsapp:')
    ) {
      return;
    }

    let absoluteUrl;
    try {
      const u = new URL(rawHref, pageUrl);
      // Remove hash fragment for testing target
      u.hash = '';
      absoluteUrl = u.toString();
    } catch (e) {
      return;
    }

    let anchorText = $(el).text().replace(/\s+/g, ' ').trim();
    if (!anchorText) {
      const imgAlt = $(el).find('img').attr('alt');
      anchorText = imgAlt ? `[Image: ${imgAlt.trim()}]` : '[No text / Icon]';
    }
    if (anchorText.length > 80) anchorText = anchorText.substring(0, 77) + '...';

    let isInternal = false;
    try {
      const linkHost = new URL(absoluteUrl).hostname;
      isInternal = linkHost === baseHostname || linkHost.endsWith('.' + baseHostname);
    } catch (e) {}

    links.push({
      targetUrl: absoluteUrl,
      sourcePage: pageUrl,
      anchorText,
      isInternal
    });
  });

  return links;
}

/**
 * Concurrency runner for checking links efficiently
 */
async function runConcurrentChecks(items, limit, workerFn) {
  const results = [];
  let index = 0;

  async function next() {
    while (index < items.length) {
      const currentIndex = index++;
      const item = items[currentIndex];
      try {
        const res = await workerFn(item, currentIndex);
        results[currentIndex] = res;
      } catch (err) {
        results[currentIndex] = null;
      }
    }
  }

  const workers = Array.from({ length: Math.min(limit, items.length) }, () => next());
  await Promise.all(workers);
  return results;
}

/**
 * Main Broken Link Checker orchestrator
 */
async function auditBrokenLinks({
  mode = 'site',          // 'site' (whole site crawl) or 'urls' (specific URLs)
  target = '',            // Root URL or first page
  rawUrls = [],           // List of URLs for 'urls' mode
  maxPages = 30,          // Maximum pages to crawl in 'site' mode
  checkExternal = true,   // Whether to verify external links found
  concurrency = 6,        // Concurrent link checks
  onProgress = null       // Callback for SSE updates
}) {
  const startTime = Date.now();
  const pagesCrawled = new Set();
  const queue = [];
  const allDiscoveredLinks = []; // { targetUrl, sourcePage, anchorText, isInternal }
  const uniqueLinkKeys = new Set();

  function addLinks(links) {
    for (const l of links) {
      if (!checkExternal && !l.isInternal) continue;
      const key = `${l.sourcePage}__${l.targetUrl}`;
      if (!uniqueLinkKeys.has(key)) {
        uniqueLinkKeys.add(key);
        allDiscoveredLinks.push(l);
      }
    }
  }

  // 1. DISCOVERY PHASE
  if (mode === 'site') {
    let normalized = target.startsWith('http') ? target : `https://${target}`;
    let baseOrigin = '';
    let baseHostname = '';
    try {
      const u = new URL(normalized);
      baseOrigin = u.origin;
      baseHostname = u.hostname;
    } catch (e) {
      throw new Error(`Invalid root URL: ${target}`);
    }

    queue.push(normalized);

    while (queue.length > 0 && pagesCrawled.size < maxPages) {
      const currentUrl = queue.shift();
      if (pagesCrawled.has(currentUrl)) continue;
      pagesCrawled.add(currentUrl);

      if (onProgress) {
        onProgress({
          type: 'crawling_page',
          url: currentUrl,
          crawledCount: pagesCrawled.size,
          maxPages,
          queueLength: queue.length,
          discoveredLinksCount: allDiscoveredLinks.length
        });
      }

      const { body } = await fetchHtml(currentUrl, 10000);
      if (!body) continue;

      const pageLinks = extractLinksFromHtml(body, currentUrl);
      addLinks(pageLinks);

      // Add newly discovered internal pages to queue
      for (const pl of pageLinks) {
        if (pl.isInternal) {
          try {
            const u = new URL(pl.targetUrl);
            const cleanPath = `${u.origin}${u.pathname}`;
            // Avoid non-html assets in page crawl queue
            if (!/\.(jpg|jpeg|png|gif|svg|pdf|zip|css|js|woff|woff2|ico|mp4)$/i.test(u.pathname)) {
              if (!pagesCrawled.has(cleanPath) && !queue.includes(cleanPath) && pagesCrawled.size + queue.length < maxPages) {
                queue.push(cleanPath);
              }
            }
          } catch (e) {}
        }
      }
    }
  } else {
    // Mode 'urls'
    const urlsToProcess = (rawUrls.length > 0 ? rawUrls : [target])
      .map(u => (typeof u === 'string' ? u.trim() : ''))
      .filter(u => u.length > 0)
      .map(u => (u.startsWith('http') ? u : `https://${u}`));

    for (let i = 0; i < urlsToProcess.length; i++) {
      const u = urlsToProcess[i];
      pagesCrawled.add(u);

      if (onProgress) {
        onProgress({
          type: 'crawling_page',
          url: u,
          crawledCount: i + 1,
          maxPages: urlsToProcess.length,
          queueLength: urlsToProcess.length - (i + 1),
          discoveredLinksCount: allDiscoveredLinks.length
        });
      }

      const { body } = await fetchHtml(u, 10000);
      if (body) {
        const pageLinks = extractLinksFromHtml(body, u);
        addLinks(pageLinks);
      }
    }

    // If no child links were found on any page (e.g. SPA, JS-rendered page),
    // fall back to verifying the provided input URLs directly so the report is not empty.
    if (allDiscoveredLinks.length === 0) {
      for (const u of urlsToProcess) {
        addLinks([{
          targetUrl: u,
          sourcePage: 'Direct Input',
          anchorText: '[Direct Link Check]',
          isInternal: true
        }]);
      }
    }
  }

  // 2. VERIFICATION PHASE
  const totalToVerify = allDiscoveredLinks.length;
  const verifiedResults = [];
  const statusCache = new Map(); // Cache target URL verification to avoid hammering same external URL repeatedly

  let checkedCount = 0;
  let brokenCount = 0;
  let redirectCount = 0;
  let okCount = 0;

  if (onProgress) {
    onProgress({
      type: 'verification_start',
      totalLinks: totalToVerify,
      totalPagesCrawled: pagesCrawled.size
    });
  }

  await runConcurrentChecks(allDiscoveredLinks, concurrency, async (linkItem, idx) => {
    let checkResult;
    if (statusCache.has(linkItem.targetUrl)) {
      checkResult = { ...statusCache.get(linkItem.targetUrl) };
    } else {
      checkResult = await verifyLinkStatus(linkItem.targetUrl, 8000);
      statusCache.set(linkItem.targetUrl, checkResult);
    }

    const fullResult = {
      ...linkItem,
      statusCode: checkResult.statusCode,
      statusCategory: checkResult.statusCategory,
      errorReason: checkResult.errorReason,
      durationMs: checkResult.durationMs,
      redirectChain: checkResult.redirectChain || [],
      finalUrl: checkResult.finalUrl || linkItem.targetUrl
    };

    verifiedResults.push(fullResult);
    checkedCount++;

    if (fullResult.statusCategory === 'broken') brokenCount++;
    else if (fullResult.statusCategory === 'redirect') redirectCount++;
    else okCount++;

    if (onProgress) {
      onProgress({
        type: 'link_checked',
        link: fullResult,
        stats: {
          checkedCount,
          totalToVerify,
          brokenCount,
          redirectCount,
          okCount,
          percent: totalToVerify > 0 ? Math.round((checkedCount / totalToVerify) * 100) : 100
        }
      });
    }

    return fullResult;
  });

  const durationSec = Math.round((Date.now() - startTime) / 1000);

  const summary = {
    mode,
    target,
    pagesCrawledCount: pagesCrawled.size,
    totalLinksChecked: checkedCount,
    brokenCount,
    redirectCount,
    okCount,
    durationSec,
    timestamp: new Date().toISOString(),
    results: verifiedResults
  };

  if (onProgress) {
    onProgress({
      type: 'done',
      summary
    });
  }

  return summary;
}

/**
 * Generate Excel (.xlsx) file for Broken Links Audit
 */
async function generateBrokenLinksExcel(auditData) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Page Speed Report & Broken Link Checker';
  workbook.created = new Date();

  const results = auditData.results || [];
  const brokenLinks = results.filter(r => r.statusCategory === 'broken');
  const redirectLinks = results.filter(r => r.statusCategory === 'redirect');
  const okLinks = results.filter(r => r.statusCategory === 'ok');

  // ---------------------------------------------------------
  // SHEET 1: Summary Dashboard
  // ---------------------------------------------------------
  const summarySheet = workbook.addWorksheet('Overview & Summary', { views: [{ showGridLines: true }] });
  summarySheet.columns = [
    { width: 4 },
    { width: 28 },
    { width: 38 },
    { width: 20 }
  ];

  summarySheet.addRow([]);
  const titleRow = summarySheet.addRow(['', 'BROKEN LINK CHECKER AUDIT REPORT', '', '']);
  titleRow.font = { name: 'Calibri', size: 16, bold: true, color: { argb: 'FF1E293B' } };
  summarySheet.addRow([]);

  const infoRows = [
    ['Audit Target', auditData.target || 'Custom URLs Batch'],
    ['Scan Mode', auditData.mode === 'site' ? 'Whole Website Crawl' : 'Provided URLs List'],
    ['Pages Crawled', auditData.pagesCrawledCount || 0],
    ['Total Links Checked', auditData.totalLinksChecked || 0],
    ['🔴 Broken Links (4xx/5xx)', brokenLinks.length],
    ['🟡 Redirects (3xx)', redirectLinks.length],
    ['🟢 Healthy Links (200 OK)', okLinks.length],
    ['Audit Date', new Date(auditData.timestamp || Date.now()).toLocaleString()]
  ];

  infoRows.forEach(([label, val]) => {
    const r = summarySheet.addRow(['', label, val]);
    r.getCell(2).font = { bold: true, color: { argb: 'FF475569' } };
    r.getCell(3).font = { bold: false };
    if (label.includes('Broken')) {
      r.getCell(3).font = { bold: true, color: { argb: 'FFDC2626' } };
    } else if (label.includes('Healthy')) {
      r.getCell(3).font = { bold: true, color: { argb: 'FF16A34A' } };
    }
  });

  // ---------------------------------------------------------
  // SHEET 2: Broken Links Only (Action List for Developers)
  // ---------------------------------------------------------
  const brokenSheet = workbook.addWorksheet('Broken Links (Fix Now)', { views: [{ showGridLines: true }] });
  brokenSheet.columns = [
    { header: '#', key: 'id', width: 6 },
    { header: 'Status', key: 'statusCode', width: 12 },
    { header: 'Error Reason', key: 'errorReason', width: 24 },
    { header: 'Broken Target URL', key: 'targetUrl', width: 45 },
    { header: 'Anchor Text / Label', key: 'anchorText', width: 30 },
    { header: 'Found On Page (Source)', key: 'sourcePage', width: 45 },
    { header: 'Type', key: 'isInternal', width: 14 },
    { header: 'Response Time (ms)', key: 'durationMs', width: 18 }
  ];

  styleHeaderRow(brokenSheet.getRow(1), 'FF7F1D1D', 'FFFFFFFF'); // Dark red header

  brokenLinks.forEach((item, i) => {
    const row = brokenSheet.addRow({
      id: i + 1,
      statusCode: item.statusCode || 'ERR',
      errorReason: item.errorReason || 'Broken',
      targetUrl: item.targetUrl,
      anchorText: item.anchorText || '[Empty]',
      sourcePage: item.sourcePage,
      isInternal: item.isInternal ? 'Internal' : 'External',
      durationMs: item.durationMs || 0
    });
    row.getCell(2).font = { bold: true, color: { argb: 'FFDC2626' } };
    row.getCell(3).font = { bold: true, color: { argb: 'FFDC2626' } };
  });

  // ---------------------------------------------------------
  // SHEET 3: Redirects (3xx)
  // ---------------------------------------------------------
  const redirectSheet = workbook.addWorksheet('Redirects (3xx)', { views: [{ showGridLines: true }] });
  redirectSheet.columns = [
    { header: '#', key: 'id', width: 6 },
    { header: 'Status', key: 'statusCode', width: 12 },
    { header: 'Target URL', key: 'targetUrl', width: 45 },
    { header: 'Final Destination URL', key: 'finalUrl', width: 45 },
    { header: 'Anchor Text', key: 'anchorText', width: 30 },
    { header: 'Found On Page', key: 'sourcePage', width: 45 },
    { header: 'Type', key: 'isInternal', width: 14 }
  ];

  styleHeaderRow(redirectSheet.getRow(1), 'FF78350F', 'FFFFFFFF'); // Amber header

  redirectLinks.forEach((item, i) => {
    redirectSheet.addRow({
      id: i + 1,
      statusCode: item.statusCode,
      targetUrl: item.targetUrl,
      finalUrl: item.finalUrl || item.targetUrl,
      anchorText: item.anchorText,
      sourcePage: item.sourcePage,
      isInternal: item.isInternal ? 'Internal' : 'External'
    });
  });

  // ---------------------------------------------------------
  // SHEET 4: All Checked Links
  // ---------------------------------------------------------
  const allSheet = workbook.addWorksheet('All Checked Links', { views: [{ showGridLines: true }] });
  allSheet.columns = [
    { header: '#', key: 'id', width: 6 },
    { header: 'Health', key: 'statusCategory', width: 12 },
    { header: 'HTTP Status', key: 'statusCode', width: 14 },
    { header: 'Target URL', key: 'targetUrl', width: 45 },
    { header: 'Anchor Text', key: 'anchorText', width: 30 },
    { header: 'Source Page', key: 'sourcePage', width: 45 },
    { header: 'Type', key: 'isInternal', width: 14 },
    { header: 'Response (ms)', key: 'durationMs', width: 16 }
  ];

  styleHeaderRow(allSheet.getRow(1), 'FF1E293B', 'FFFFFFFF'); // Slate header

  results.forEach((item, i) => {
    const row = allSheet.addRow({
      id: i + 1,
      statusCategory: item.statusCategory.toUpperCase(),
      statusCode: item.statusCode || 'ERR',
      targetUrl: item.targetUrl,
      anchorText: item.anchorText,
      sourcePage: item.sourcePage,
      isInternal: item.isInternal ? 'Internal' : 'External',
      durationMs: item.durationMs || 0
    });

    if (item.statusCategory === 'broken') {
      row.getCell(2).font = { bold: true, color: { argb: 'FFDC2626' } };
      row.getCell(3).font = { bold: true, color: { argb: 'FFDC2626' } };
    } else if (item.statusCategory === 'redirect') {
      row.getCell(2).font = { bold: true, color: { argb: 'FFD97706' } };
    } else {
      row.getCell(2).font = { bold: true, color: { argb: 'FF16A34A' } };
    }
  });

  return await workbook.xlsx.writeBuffer();
}

function styleHeaderRow(row, bgArgb, textArgb) {
  row.height = 26;
  row.font = { bold: true, color: { argb: textArgb }, size: 11 };
  row.alignment = { vertical: 'middle', horizontal: 'left' };
  row.eachCell((cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: bgArgb }
    };
    cell.border = {
      bottom: { style: 'thin', color: { argb: 'FF000000' } }
    };
  });
}

module.exports = {
  auditBrokenLinks,
  verifyLinkStatus,
  generateBrokenLinksExcel
};
