const cheerio = require('cheerio');
const https = require('https');
const http = require('http');

/**
 * 360° AEO (Answer Engine Optimization) & GEO (Generative Engine Optimization) Audit Matrix.
 * Evaluates readiness for ChatGPT Search, Google AI Overviews, Perplexity AI, Claude, Gemini, and Apple Intelligence.
 * Built according to 10+ years senior enterprise architectural standards.
 */
async function auditAEO(targetUrl, existingHtml = null, robotsTxtContent = null, llmsTxtFound = false) {
  const normalizedUrl = targetUrl.startsWith('http') ? targetUrl : `https://${targetUrl}`;
  let parsedUrl;
  try {
    parsedUrl = new URL(normalizedUrl);
  } catch (err) {
    throw new Error(`Invalid URL for AEO: ${normalizedUrl}`);
  }

  // 1. Fetch HTML if not already passed from SEO module
  let body = existingHtml;
  if (!body) {
    const pageData = await fetchText(normalizedUrl);
    body = pageData.body;
  }

  // 2. Fetch robots.txt if not already passed
  let robotsTxt = robotsTxtContent;
  if (robotsTxt === null) {
    const robotsUrl = `${parsedUrl.origin}/robots.txt`;
    const robotsData = await fetchText(robotsUrl);
    robotsTxt = robotsData.statusCode === 200 ? robotsData.body : '';
  }

  const $ = cheerio.load(body || '');

  // ----------------------------------------------------
  // PILLAR 1: AI BOTS & LLM RETRIEVAL ACCESSIBILITY
  // ----------------------------------------------------
  const aiBots = [
    { name: 'GPTBot', company: 'OpenAI', purpose: 'ChatGPT model training & knowledge ingestion' },
    { name: 'ChatGPT-User', company: 'OpenAI', purpose: 'ChatGPT live user search & real-time browsing' },
    { name: 'PerplexityBot', company: 'Perplexity AI', purpose: 'Perplexity search engine answer generation' },
    { name: 'Google-Extended', company: 'Google Gemini', purpose: 'Gemini and Vertex AI training & citation' },
    { name: 'GoogleOther', company: 'Google', purpose: 'Google AI Overviews retrieval' },
    { name: 'ClaudeBot', company: 'Anthropic', purpose: 'Claude AI answer generation & citations' },
    { name: 'anthropic-ai', company: 'Anthropic', purpose: 'Anthropic foundation model retrieval' },
    { name: 'Applebot-Extended', company: 'Apple', purpose: 'Apple Intelligence Siri & Spotlight AI' },
    { name: 'cohere-ai', company: 'Cohere', purpose: 'Enterprise Cohere RAG model retrieval' },
    { name: 'Bytespider', company: 'ByteDance', purpose: 'TikTok & ByteDance AI search' }
  ];

  const aiBotStatus = [];
  let blockedAiBotCount = 0;

  aiBots.forEach(bot => {
    const isBlocked = checkBotBlocked(robotsTxt, bot.name);
    if (isBlocked) blockedAiBotCount++;
    aiBotStatus.push({
      bot: bot.name,
      company: bot.company,
      purpose: bot.purpose,
      allowed: !isBlocked,
      status: !isBlocked ? 'Allowed (Visible to AI)' : 'Blocked (Disallowed in robots.txt)'
    });
  });

  const aiBotsAllowedCount = aiBots.length - blockedAiBotCount;

  // ----------------------------------------------------
  // PILLAR 2: STRUCTURED DATA & KNOWLEDGE GRAPH (Schema.org)
  // ----------------------------------------------------
  const schemaScripts = $('script[type="application/ld+json"]');
  const schemasFound = [];
  let sameAsLinks = [];
  let schemaAuthorFound = false;

  schemaScripts.each((_, el) => {
    try {
      const json = JSON.parse($(el).html());
      extractAeoSchemas(json, schemasFound, sameAsLinks);
      if (JSON.stringify(json).includes('"author"')) {
        schemaAuthorFound = true;
      }
    } catch (e) {
      // ignore json parse error
    }
  });

  const uniqueSchemas = [...new Set(schemasFound)];
  const hasFaqSchema = uniqueSchemas.some(s => /FAQPage/i.test(s));
  const hasHowToSchema = uniqueSchemas.some(s => /HowTo/i.test(s));
  const hasSpeakableSchema = uniqueSchemas.some(s => /Speakable/i.test(s));
  const hasArticleSchema = uniqueSchemas.some(s => /Article|BlogPosting|NewsArticle|TechArticle/i.test(s));
  const hasOrgSchema = uniqueSchemas.some(s => /Organization|LocalBusiness|Corporation/i.test(s));
  const hasBreadcrumbsSchema = uniqueSchemas.some(s => /BreadcrumbList/i.test(s));
  const hasSameAs = sameAsLinks.length > 0;

  // ----------------------------------------------------
  // PILLAR 3: QUESTION & ANSWER CHUNKING (Direct 40-60w Answers)
  // ----------------------------------------------------
  // AI engines look for conversational question headings with concise direct answers
  const questionPattern = /^(what|how|why|can|is|are|will|when|where|which|who|does|do|should|cost|best|guide|difference)\b|\?$/i;
  const questionHeadings = [];
  const detectedQA = [];

  $('h2, h3, h4').each((_, el) => {
    const headingText = $(el).text().trim().replace(/\s+/g, ' ');
    if (questionPattern.test(headingText)) {
      questionHeadings.push(headingText);

      // Inspect immediate next sibling paragraph
      let nextPara = $(el).next('p').text().trim();
      if (!nextPara) {
        nextPara = $(el).nextUntil('h2, h3, h4', 'p').first().text().trim();
      }

      const wordCount = nextPara ? nextPara.split(/\s+/).length : 0;
      // 35-70 word sweet spot for Google AI Overviews and Perplexity direct citation
      const isOptimalAnswerLength = wordCount >= 35 && wordCount <= 70;

      detectedQA.push({
        question: headingText,
        answer: nextPara ? nextPara.slice(0, 220) + (nextPara.length > 220 ? '…' : '') : '(No direct paragraph answer found immediately following heading)',
        wordCount,
        isOptimalAnswerLength,
        status: isOptimalAnswerLength ? 'Optimal (40-60 words)' : (wordCount === 0 ? 'Missing Answer' : (wordCount < 35 ? 'Too Brief' : 'Too Long for Direct Snippet'))
      });
    }
  });

  const optimalAnswersCount = detectedQA.filter(q => q.isOptimalAnswerLength).length;

  // ----------------------------------------------------
  // PILLAR 4: CONTENT CHUNKABILITY, TABLES & LISTS
  // ----------------------------------------------------
  const bulletListsCount = $('ul').length;
  const numberedListsCount = $('ol').length;
  const tablesCount = $('table').length;
  const totalListItems = $('li').length;
  const definitionListsCount = $('dl').length;
  const blockquotesCount = $('blockquote').length;

  // Inspect paragraph lengths for atomic chunk retrieval
  const paragraphs = $('p');
  let totalParaWords = 0;
  let shortParaCount = 0; // <= 60 words
  let longParaCount = 0;

  paragraphs.each((_, el) => {
    const text = $(el).text().trim();
    if (text) {
      const words = text.split(/\s+/).length;
      totalParaWords += words;
      if (words <= 60) shortParaCount++;
      else longParaCount++;
    }
  });

  const avgParaWords = paragraphs.length > 0 ? Math.round(totalParaWords / paragraphs.length) : 0;

  // ----------------------------------------------------
  // PILLAR 5: E-E-A-T, FACT DENSITY & AUTHORITY CITATIONS
  // ----------------------------------------------------
  const hasAuthorByline = $('[class*="author" i], [rel="author" i], [itemprop="author" i], .byline').length > 0 || schemaAuthorFound;
  const hasDatePublished = $('time, [class*="date" i], [itemprop="datePublished" i], meta[property="article:published_time" i]').length > 0;
  const hasDateModified = $('[itemprop="dateModified" i], meta[property="article:modified_time" i]').length > 0;

  // Outbound Authority Citations (links to .edu, .gov, wikipedia, doi, research)
  let authorityCitationCount = 0;
  const citedDomains = [];
  $('a[href^="http"]').each((_, el) => {
    const href = $(el).attr('href') || '';
    if (!href.includes(parsedUrl.hostname) && (/\.edu|\.gov|wikipedia\.org|doi\.org|ncbi|w3\.org|arxiv\.org|nature\.com/i.test(href))) {
      authorityCitationCount++;
      try {
        citedDomains.push(new URL(href).hostname);
      } catch (_) {}
    }
  });

  // Fact & Statistics Density (percentages %, numerical figures, currencies $, €, £)
  const $clean = cheerio.load(body || '');
  $clean('script, style, noscript, svg, head, iframe').remove();
  const visibleText = $clean('body').text().replace(/\s+/g, ' ').trim();
  
  const statMatches = visibleText.match(/\b\d+(\.\d+)?%|\$\d+|\€\d+|\£\d+|\b(19\d\d|20\d\d)\b/g) || [];
  const statCount = statMatches.length;
  const statDensityScore = Math.min(100, Math.round((statCount / (visibleText.split(/\s+/).length || 1)) * 1000));

  // ----------------------------------------------------
  // PILLAR 6: READABILITY & LINGUISTIC PROCESSING
  // ----------------------------------------------------
  const readability = calculateFleschReadingEase(visibleText);
  const sentenceComplexity = calculateSentenceMetrics(visibleText);

  // ----------------------------------------------------
  // CALCULATE OVERALL AEO READINESS SCORE (0 - 100)
  // ----------------------------------------------------
  let aeoScore = 100;
  const aeoDeductions = [];

  // Schema & Knowledge Graph (max -25)
  if (!hasFaqSchema) {
    aeoScore -= 8;
    aeoDeductions.push('Missing FAQPage Schema (-8)');
  }
  if (!hasSpeakableSchema) {
    aeoScore -= 5;
    aeoDeductions.push('Missing Speakable Schema for Voice/Assistant Devices (-5)');
  }
  if (!hasOrgSchema && !hasArticleSchema) {
    aeoScore -= 5;
    aeoDeductions.push('Missing Organization / Article Schema (-5)');
  }
  if (!hasSameAs) {
    aeoScore -= 4;
    aeoDeductions.push('Missing sameAs Authority Links (Wikipedia/LinkedIn/Wikidata) in Schema (-4)');
  }

  // Q&A / Direct Answers (max -25)
  if (questionHeadings.length === 0) {
    aeoScore -= 14;
    aeoDeductions.push('No question-based headings detected (What/How/Why...) (-14)');
  } else {
    if (optimalAnswersCount === 0) {
      aeoScore -= 8;
      aeoDeductions.push('No concise 40-60 word direct answers under question headings (-8)');
    }
  }

  // AI Bots Accessibility & llms.txt (max -20)
  if (blockedAiBotCount > 0) {
    const penalty = Math.min(18, blockedAiBotCount * 4);
    aeoScore -= penalty;
    aeoDeductions.push(`${blockedAiBotCount} AI Crawlers blocked in robots.txt (-${penalty})`);
  }
  if (!llmsTxtFound) {
    aeoScore -= 4;
    aeoDeductions.push('Missing /llms.txt standard file for LLM documentation (-4)');
  }

  // Scannability / Lists & Tables (max -15)
  if (bulletListsCount === 0 && numberedListsCount === 0) {
    aeoScore -= 8;
    aeoDeductions.push('No bulleted or numbered lists for AI step extraction (-8)');
  }
  if (tablesCount === 0) {
    aeoScore -= 4;
    aeoDeductions.push('No comparison/data tables for AI snippet ingestion (-4)');
  }

  // EEAT Signals (max -15)
  if (!hasAuthorByline) {
    aeoScore -= 5;
    aeoDeductions.push('Missing author byline / EEAT attribution (-5)');
  }
  if (!hasDatePublished) {
    aeoScore -= 3;
    aeoDeductions.push('Missing publication / last modified date (-3)');
  }

  // Readability & Sentence Complexity (max -10)
  if (readability.score < 45) {
    aeoScore -= 4;
    aeoDeductions.push('High reading difficulty - difficult for AI summary generation (-4)');
  }
  if (sentenceComplexity.avgWordsPerSentence > 25) {
    aeoScore -= 3;
    aeoDeductions.push('Average sentence length > 25 words (increases LLM hallucination risk) (-3)');
  }

  aeoScore = Math.max(15, Math.min(100, aeoScore));

  let readinessGrade = 'A+ (AI Ready)';
  if (aeoScore < 50) readinessGrade = 'F (Unprepared for AI Search)';
  else if (aeoScore < 65) readinessGrade = 'D (Weak AI Visibility)';
  else if (aeoScore < 75) readinessGrade = 'C (Needs Optimization)';
  else if (aeoScore < 88) readinessGrade = 'B (Good AI Foundation)';
  else if (aeoScore < 95) readinessGrade = 'A (Highly AI Optimized)';

  return {
    url: targetUrl,
    aeoScore,
    readinessGrade,
    summary: {
      schemasDetected: uniqueSchemas,
      questionHeadingsCount: questionHeadings.length,
      optimalAnswersCount,
      aiBotsAllowedCount,
      aiBotsBlockedCount: blockedAiBotCount,
      totalAiBotsCount: aiBots.length,
      listsCount: bulletListsCount + numberedListsCount,
      tablesCount,
      definitionListsCount,
      hasFaqSchema,
      hasSpeakableSchema,
      hasHowToSchema,
      hasArticleSchema,
      hasOrgSchema,
      hasSameAs,
      hasAuthorByline,
      hasDatePublished,
      hasDateModified,
      llmsTxtFound,
      authorityCitationCount,
      statCount,
      readabilityScore: readability.score,
      readabilityGrade: readability.grade,
      avgWordsPerSentence: sentenceComplexity.avgWordsPerSentence
    },
    aiBotStatus,
    llmsTxt: {
      found: llmsTxtFound,
      url: `${parsedUrl.origin}/llms.txt`,
      status: llmsTxtFound ? 'Present (Optimal)' : 'Not Found (/llms.txt recommended for LLM ingestion)'
    },
    schemas: {
      uniqueSchemas,
      hasFaqSchema,
      hasHowToSchema,
      hasSpeakableSchema,
      hasArticleSchema,
      hasOrgSchema,
      hasBreadcrumbsSchema,
      hasSameAs,
      sameAsLinks: [...new Set(sameAsLinks)].slice(0, 8)
    },
    qaAnalysis: {
      totalQuestions: questionHeadings.length,
      optimalAnswersCount,
      detectedQA: detectedQA.slice(0, 10) // top 10 QA items
    },
    scannability: {
      bulletListsCount,
      numberedListsCount,
      totalListItems,
      tablesCount,
      definitionListsCount,
      blockquotesCount,
      avgParaWords,
      shortParaCount,
      longParaCount
    },
    eeat: {
      hasAuthorByline,
      hasDatePublished,
      hasDateModified,
      authorityCitationCount,
      citedDomains: [...new Set(citedDomains)].slice(0, 6),
      statCount,
      statDensityScore
    },
    readability: {
      ...readability,
      ...sentenceComplexity
    },
    deductions: aeoDeductions
  };
}

function extractAeoSchemas(json, schemaList, sameAsList) {
  if (!json) return;
  if (Array.isArray(json)) {
    json.forEach(item => extractAeoSchemas(item, schemaList, sameAsList));
  } else if (typeof json === 'object') {
    if (json['@type']) {
      if (Array.isArray(json['@type'])) {
        json['@type'].forEach(t => schemaList.push(t));
      } else {
        schemaList.push(json['@type']);
      }
    }
    if (json.sameAs) {
      if (Array.isArray(json.sameAs)) {
        json.sameAs.forEach(s => sameAsList.push(s));
      } else if (typeof json.sameAs === 'string') {
        sameAsList.push(json.sameAs);
      }
    }
    if (json['@graph'] && Array.isArray(json['@graph'])) {
      json['@graph'].forEach(item => extractAeoSchemas(item, schemaList, sameAsList));
    }
  }
}

/**
 * Check if a specific AI bot user-agent is disallowed in robots.txt
 */
function checkBotBlocked(robotsTxt, botName) {
  if (!robotsTxt) return false;
  const lines = robotsTxt.split(/\r?\n/);
  let currentAgent = '';
  let isDisallowed = false;

  for (let line of lines) {
    line = line.trim();
    if (line.startsWith('#') || !line) continue;

    const lower = line.toLowerCase();
    if (lower.startsWith('user-agent:')) {
      currentAgent = line.slice(11).trim();
      continue;
    }

    // Direct match for target bot or wildcard '*'
    const matchesTarget = currentAgent.toLowerCase() === botName.toLowerCase();
    const matchesWildcard = currentAgent === '*';

    if (matchesTarget || matchesWildcard) {
      if (lower.startsWith('disallow:')) {
        const path = line.slice(9).trim();
        if (path === '/' || path === '/*') {
          isDisallowed = true;
        }
      } else if (lower.startsWith('allow:')) {
        const path = line.slice(6).trim();
        if (path === '/' || path === '/*') {
          isDisallowed = false;
        }
      }
    }
  }

  return isDisallowed;
}

/**
 * Flesch Reading Ease score calculation
 */
function calculateFleschReadingEase(text) {
  if (!text || text.length < 50) {
    return { score: 70, grade: 'Standard', interpretation: 'Plain English' };
  }

  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = text.split(/\s+/).filter(w => w.trim().length > 0);
  const totalSentences = Math.max(1, sentences.length);
  const totalWords = Math.max(1, words.length);

  let totalSyllables = 0;
  words.forEach(w => {
    totalSyllables += countSyllables(w.toLowerCase().replace(/[^a-z]/g, ''));
  });

  const wordsPerSentence = totalWords / totalSentences;
  const syllablesPerWord = totalSyllables / totalWords;
  const score = Math.round(206.835 - (1.015 * wordsPerSentence) - (84.6 * syllablesPerWord));
  const clampedScore = Math.max(0, Math.min(100, score));

  let grade = 'Standard (8th-9th Grade)';
  let interpretation = 'Conversational, easy for AI to summarize';
  if (clampedScore >= 90) {
    grade = 'Very Easy (5th Grade)';
    interpretation = 'Easily understood by any conversational agent';
  } else if (clampedScore >= 80) {
    grade = 'Easy (6th Grade)';
    interpretation = 'Conversational prose, clear for LLMs';
  } else if (clampedScore >= 70) {
    grade = 'Fairly Easy (7th Grade)';
    interpretation = 'Standard web writing, optimal for AI search';
  } else if (clampedScore >= 60) {
    grade = 'Standard (8th-9th Grade)';
    interpretation = 'Plain English, well-suited for AI synthesis';
  } else if (clampedScore >= 50) {
    grade = 'Fairly Difficult (10th-12th Grade)';
    interpretation = 'Some complex terminology, may cause slight compression ambiguity';
  } else if (clampedScore >= 30) {
    grade = 'Difficult (College)';
    interpretation = 'Academic prose, harder for AI to extract quick answers';
  } else {
    grade = 'Very Difficult (College Graduate)';
    interpretation = 'Dense technical text, prone to LLM hallucination or omission';
  }

  return { score: clampedScore, grade, interpretation };
}

function calculateSentenceMetrics(text) {
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = text.split(/\s+/).filter(w => w.trim().length > 0);
  const totalSentences = Math.max(1, sentences.length);
  const totalWords = Math.max(1, words.length);
  const avgWordsPerSentence = Math.round(totalWords / totalSentences);

  return {
    totalSentences,
    totalWords,
    avgWordsPerSentence
  };
}

function countSyllables(word) {
  if (!word) return 1;
  if (word.length <= 3) return 1;
  word = word.replace(/(?:[^laeiouy]|ed|es|e)$/, '');
  word = word.replace(/^y/, '');
  const matches = word.match(/[aeiouy]{1,2}/g);
  return matches ? Math.max(1, matches.length) : 1;
}

function fetchText(url) {
  return new Promise((resolve) => {
    try {
      const parsed = new URL(url);
      const client = parsed.protocol === 'https:' ? https : http;
      const req = client.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 PageSpeedReportBot/2.0' },
        timeout: 8000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ statusCode: res.statusCode || 200, body: data }));
      });
      req.on('error', () => resolve({ statusCode: 0, body: '' }));
      req.setTimeout(8000, () => { req.destroy(); resolve({ statusCode: 408, body: '' }); });
    } catch (_) {
      resolve({ statusCode: 0, body: '' });
    }
  });
}

module.exports = {
  auditAEO
};
