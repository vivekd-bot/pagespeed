const cheerio = require('cheerio');
const https = require('https');
const http = require('http');
const { validateSafeUrl } = require('./security');

// Domain-level cache for robots.txt, sitemap.xml, and llms.txt to prevent hammering in large batches
const domainMetaCache = new Map();

async function getDomainMeta(origin) {
  if (domainMetaCache.has(origin)) {
    return domainMetaCache.get(origin);
  }
  const promise = (async () => {
    const robotsUrl = `${origin}/robots.txt`;
    const sitemapUrl = `${origin}/sitemap.xml`;
    const llmsUrl = `${origin}/llms.txt`;
    try {
      const [robotsData, sitemapResult, llmsResult] = await Promise.all([
        fetchTextQuick(robotsUrl, 5000),
        checkUrlStatus(sitemapUrl, 5000),
        checkUrlStatus(llmsUrl, 4000)
      ]);
      const robotsTxtBody = robotsData.body || '';
      const hasSitemapInRobots = /Sitemap:\s*https?:\/\//i.test(robotsTxtBody);

      return {
        robotsResult: { exists: robotsData.statusCode >= 200 && robotsData.statusCode < 400, statusCode: robotsData.statusCode },
        robotsTxtBody,
        hasSitemapInRobots,
        sitemapResult,
        llmsResult
      };
    } catch (_) {
      return {
        robotsResult: { exists: false, statusCode: 0 },
        robotsTxtBody: '',
        hasSitemapInRobots: false,
        sitemapResult: { exists: false, statusCode: 0 },
        llmsResult: { exists: false, statusCode: 0 }
      };
    }
  })();
  domainMetaCache.set(origin, promise);
  return promise;
}

function fetchTextQuick(url, timeoutMs = 5000) {
  return new Promise((resolve) => {
    try {
      const parsed = new URL(url);
      const client = parsed.protocol === 'https:' ? https : http;
      const req = client.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) PageSpeedReportBot/2.0' },
        timeout: timeoutMs
      }, (res) => {
        let data = '';
        res.on('data', chunk => {
          data += chunk;
          if (data.length > 250000) { // Limit to 250KB
            req.destroy();
            resolve({ statusCode: res.statusCode || 200, body: data });
          }
        });
        res.on('end', () => resolve({ statusCode: res.statusCode || 200, body: data }));
      });
      req.on('error', () => resolve({ statusCode: 0, body: '' }));
      req.setTimeout(timeoutMs, () => { req.destroy(); resolve({ statusCode: 408, body: '' }); });
    } catch (_) {
      resolve({ statusCode: 0, body: '' });
    }
  });
}

function checkUrlStatus(url, timeoutMs = 4000) {
  return new Promise((resolve) => {
    try {
      const parsed = new URL(url);
      const client = parsed.protocol === 'https:' ? https : http;
      const req = client.request(url, { method: 'HEAD', timeout: timeoutMs, headers: { 'User-Agent': 'Mozilla/5.0 PageSpeedReportBot/2.0' } }, (res) => {
        resolve({ exists: res.statusCode >= 200 && res.statusCode < 400, statusCode: res.statusCode });
      });
      req.on('error', () => resolve({ exists: false, statusCode: 0 }));
      req.setTimeout(timeoutMs, () => {
        req.destroy();
        resolve({ exists: false, statusCode: 408 });
      });
      req.end();
    } catch (e) {
      resolve({ exists: false, statusCode: 0 });
    }
  });
}

/**
 * 360° Semrush & Ahrefs-Grade Enterprise SEO Site Audit (10+ Years Experience Matrix)
 * Covers: Crawlability, On-Page Semantic Hierarchy, Technical & Security, Media Assets, Link Equity, Rich Snippets.
 */
async function auditSEO(targetUrl) {
  const check = validateSafeUrl(targetUrl);
  if (!check.safe) {
    throw new Error(`Security validation failed: ${check.error}`);
  }
  const normalizedUrl = check.parsed.href;
  const parsedUrl = check.parsed;

  // 1. Fetch main page HTML and HTTP headers
  const pageData = await fetchUrl(normalizedUrl);
  const { statusCode, headers, body, responseTimeMs, finalUrl } = pageData;

  // 2. Fetch domain metadata (cached)
  const { robotsResult, robotsTxtBody, hasSitemapInRobots, sitemapResult, llmsResult } = await getDomainMeta(parsedUrl.origin);

  // 3. Parse HTML with cheerio
  const $ = cheerio.load(body || '');

  // ----------------------------------------------------
  // PILLAR 1: CRAWLABILITY, INDEXING & URL ARCHITECTURE
  // ----------------------------------------------------
  const xRobotsTag = headers['x-robots-tag'] || '';
  const metaRobots = $('meta[name="robots" i]').attr('content') || '';
  const combinedRobots = `${metaRobots} ${xRobotsTag}`.toLowerCase();

  const isNoIndex = /noindex/i.test(combinedRobots);
  const isNoFollow = /nofollow/i.test(combinedRobots);
  const isNoArchive = /noarchive/i.test(combinedRobots);
  const isNoSnippet = /nosnippet/i.test(combinedRobots);

  // Canonical Tag Analysis
  const canonicalTag = $('link[rel="canonical" i]').attr('href')?.trim() || '';
  let canonicalStatus = 'Good';
  let canonicalIssue = null;
  let isSelfCanonical = false;
  let isCrossDomainCanonical = false;

  if (!canonicalTag) {
    canonicalStatus = 'Warning';
    canonicalIssue = 'Missing <link rel="canonical"> tag. Susceptible to duplicate content issues.';
  } else {
    try {
      const canonicalObj = new URL(canonicalTag, parsedUrl.origin);
      if (canonicalObj.origin !== parsedUrl.origin) {
        isCrossDomainCanonical = true;
        canonicalStatus = 'Warning';
        canonicalIssue = `Cross-domain canonical points to ${canonicalObj.origin}`;
      } else if (canonicalObj.href === parsedUrl.href || canonicalObj.pathname === parsedUrl.pathname) {
        isSelfCanonical = true;
      }
    } catch (_) {
      canonicalStatus = 'Error';
      canonicalIssue = `Malformed canonical URL: "${canonicalTag}"`;
    }
  }

  // URL Structure Analysis
  const cleanPath = parsedUrl.pathname;
  const hasUppercaseUrl = /[A-Z]/.test(cleanPath);
  const hasUnderscoresUrl = /_/.test(cleanPath);
  const hasQueryParams = parsedUrl.search.length > 0;
  const pathDepth = cleanPath.split('/').filter(Boolean).length;
  const isCleanSlug = !hasUppercaseUrl && !hasUnderscoresUrl && !hasQueryParams && cleanPath.length <= 90;

  // ----------------------------------------------------
  // PILLAR 2: ON-PAGE & SEMANTIC HEADING HIERARCHY
  // ----------------------------------------------------
  // Title Tag (chars & estimated pixel width for desktop SERP limit ~580px)
  const titleText = $('title').first().text().trim();
  const titleLength = titleText.length;
  const titlePixelWidthEst = Math.round(titleLength * 9.2);
  let titleStatus = 'Good';
  let titleIssue = null;
  if (!titleText) {
    titleStatus = 'Error';
    titleIssue = 'Missing <title> tag completely.';
  } else if (titleLength < 30) {
    titleStatus = 'Warning';
    titleIssue = `Title is too short (${titleLength} chars). Optimal: 50-60 characters.`;
  } else if (titleLength > 65) {
    titleStatus = 'Warning';
    titleIssue = `Title exceeds 65 chars (${titleLength} chars, ~${titlePixelWidthEst}px). Google SERP will truncate it.`;
  }

  // Meta Description
  const metaDesc = $('meta[name="description" i]').attr('content')?.trim() || '';
  const descLength = metaDesc.length;
  let descStatus = 'Good';
  let descIssue = null;
  if (!metaDesc) {
    descStatus = 'Error';
    descIssue = 'Missing meta description tag.';
  } else if (descLength < 70) {
    descStatus = 'Warning';
    descIssue = `Meta description is short (${descLength} chars). Recommended: 120-160 characters.`;
  } else if (descLength > 165) {
    descStatus = 'Warning';
    descIssue = `Meta description is too long (${descLength} chars). May be truncated in mobile/desktop SERPs.`;
  }

  // Headings & Structural Integrity
  const h1Elements = $('h1');
  const h1Count = h1Elements.length;
  const h1Texts = [];
  h1Elements.each((_, el) => {
    const text = $(el).text().trim().replace(/\s+/g, ' ');
    if (text) h1Texts.push(text);
  });
  const h2Count = $('h2').length;
  const h3Count = $('h3').length;
  const h4Count = $('h4').length;
  const h5Count = $('h5').length;
  const h6Count = $('h6').length;

  let h1Status = 'Good';
  let h1Issue = null;
  if (h1Count === 0) {
    h1Status = 'Error';
    h1Issue = 'No H1 heading found on page. Every indexable page requires exactly one unique H1.';
  } else if (h1Count > 1) {
    h1Status = 'Warning';
    h1Issue = `Multiple H1 headings detected (${h1Count}). Best practice is to have exactly one primary H1.`;
  }

  // Heading hierarchy skip detection (e.g. H1 followed directly by H3 or H4)
  let hasHeadingSkips = false;
  if (h1Count > 0 && h2Count === 0 && (h3Count > 0 || h4Count > 0)) {
    hasHeadingSkips = true;
  }

  // Empty headings check
  let emptyHeadingsCount = 0;
  $('h1, h2, h3, h4, h5, h6').each((_, el) => {
    if (!$(el).text().trim() && !$(el).find('img').length) emptyHeadingsCount++;
  });

  // ----------------------------------------------------
  // PILLAR 3: IMAGES & VISUAL ASSET OPTIMIZATION
  // ----------------------------------------------------
  const images = $('img');
  const totalImages = images.length;
  let missingAltCount = 0;
  let emptyAltCount = 0;
  let nextGenFormatCount = 0;
  let missingDimensionsCount = 0; // Missing width/height = major CLS cause

  images.each((_, el) => {
    const alt = $(el).attr('alt');
    const src = $(el).attr('src') || $(el).attr('data-src') || '';
    const width = $(el).attr('width');
    const height = $(el).attr('height');

    if (alt === undefined) {
      missingAltCount++;
    } else if (alt.trim() === '') {
      emptyAltCount++;
    }

    if (/\.(webp|avif|svg)(\?.*)?$/i.test(src)) {
      nextGenFormatCount++;
    }

    if (!width || !height) {
      missingDimensionsCount++;
    }
  });

  // ----------------------------------------------------
  // PILLAR 4: LINK ARCHITECTURE, ANCHORS & ATTRIBUTES
  // ----------------------------------------------------
  const links = $('a[href]');
  const totalLinks = links.length;
  let internalLinks = 0;
  let externalLinks = 0;
  let nofollowLinks = 0;
  let sponsoredLinks = 0;
  let ugcLinks = 0;
  let emptyAnchorLinks = 0;
  let insecureInternalLinks = 0;

  links.each((_, el) => {
    const href = $(el).attr('href')?.trim() || '';
    const rel = ($(el).attr('rel') || '').toLowerCase();
    const text = $(el).text().trim();

    if (!text && !$(el).find('img').length && !$(el).attr('aria-label')) {
      emptyAnchorLinks++;
    }
    if (rel.includes('nofollow')) nofollowLinks++;
    if (rel.includes('sponsored')) sponsoredLinks++;
    if (rel.includes('ugc')) ugcLinks++;

    if (href.startsWith('http://') || href.startsWith('https://')) {
      try {
        const linkUrl = new URL(href);
        if (linkUrl.hostname === parsedUrl.hostname) {
          internalLinks++;
          if (linkUrl.protocol === 'http:' && parsedUrl.protocol === 'https:') {
            insecureInternalLinks++;
          }
        } else {
          externalLinks++;
        }
      } catch (e) {
        externalLinks++;
      }
    } else if (href.startsWith('/') || href.startsWith('./') || (!href.startsWith('#') && !href.startsWith('mailto:') && !href.startsWith('tel:') && !href.startsWith('javascript:'))) {
      internalLinks++;
    }
  });

  // ----------------------------------------------------
  // PILLAR 5: TECHNICAL, SECURITY & MOBILE READINESS
  // ----------------------------------------------------
  const isHttps = parsedUrl.protocol === 'https:';
  const hasHsts = !!(headers && headers['strict-transport-security']);
  const hasXContentTypeOptions = !!(headers && headers['x-content-type-options']);
  const hasXFrameOptions = !!(headers && headers['x-frame-options']);
  const hasCsp = !!(headers && (headers['content-security-policy'] || headers['x-content-security-policy']));
  const hasViewport = $('meta[name="viewport" i]').length > 0;
  const htmlLang = $('html').attr('lang')?.trim() || '';
  const charset = $('meta[charset]').attr('charset') || $('meta[http-equiv="Content-Type" i]').attr('content') || 'utf-8';
  const hasFavicon = $('link[rel*="icon" i]').length > 0;
  const hasHreflang = $('link[rel="alternate"][hreflang]').length > 0;

  // Mixed Content Check (HTTP scripts/styles/images on HTTPS page)
  let mixedContentCount = 0;
  if (isHttps) {
    $('script[src^="http://"], link[href^="http://"][rel="stylesheet"], img[src^="http://"], iframe[src^="http://"]').each(() => {
      mixedContentCount++;
    });
  }

  // Security Headers Score (0-4)
  let securityHeadersScore = 0;
  if (hasHsts) securityHeadersScore++;
  if (hasXContentTypeOptions) securityHeadersScore++;
  if (hasXFrameOptions) securityHeadersScore++;
  if (hasCsp) securityHeadersScore++;

  // ----------------------------------------------------
  // PILLAR 6: SOCIAL PROTOCOL & STRUCTURED DATA (SCHEMA.ORG)
  // ----------------------------------------------------
  // Open Graph (Facebook / LinkedIn)
  const ogTitle = $('meta[property="og:title" i]').attr('content')?.trim() || '';
  const ogDesc = $('meta[property="og:description" i]').attr('content')?.trim() || '';
  const ogImage = $('meta[property="og:image" i]').attr('content')?.trim() || '';
  const ogUrl = $('meta[property="og:url" i]').attr('content')?.trim() || '';
  const ogType = $('meta[property="og:type" i]').attr('content')?.trim() || '';
  const ogSiteName = $('meta[property="og:site_name" i]').attr('content')?.trim() || '';
  const hasCompleteOg = !!(ogTitle && ogDesc && ogImage);

  // Twitter Card
  const twitterCard = $('meta[name="twitter:card" i]').attr('content')?.trim() || '';
  const twitterSite = $('meta[name="twitter:site" i]').attr('content')?.trim() || '';
  const twitterCreator = $('meta[name="twitter:creator" i]').attr('content')?.trim() || '';
  const hasTwitterCard = !!twitterCard;

  // Structured Data / Schema.org
  const schemaScripts = $('script[type="application/ld+json"]');
  const schemaTypesFound = [];
  schemaScripts.each((_, el) => {
    try {
      const json = JSON.parse($(el).html());
      extractSchemaTypes(json, schemaTypesFound);
    } catch (e) {
      // JSON parse error
    }
  });
  const hasMicrodata = $('[itemscope]').length > 0;
  const hasSchema = schemaScripts.length > 0 || hasMicrodata;

  // ----------------------------------------------------
  // CONTENT DEPTH & TEXT-TO-HTML RATIO
  // ----------------------------------------------------
  // Remove non-content elements for accurate text extraction
  const $clone = cheerio.load(body || '');
  $clone('script, style, noscript, svg, head, iframe').remove();
  const visibleText = $clone('body').text().replace(/\s+/g, ' ').trim();
  const wordCount = visibleText ? visibleText.split(/\s+/).length : 0;
  const htmlSize = (body || '').length;
  const textSize = visibleText.length;
  const textHtmlRatio = htmlSize > 0 ? parseFloat(((textSize / htmlSize) * 100).toFixed(1)) : 0;
  const isThinContent = wordCount < 300;

  // ----------------------------------------------------
  // SEMRUSH-GRADE OVERALL SEO HEALTH SCORE (0 - 100)
  // ----------------------------------------------------
  let healthScore = 100;
  let criticalCount = 0;
  let warningCount = 0;
  let noticeCount = 0;

  // Critical penalties (-10 to -15)
  if (statusCode >= 400 || statusCode === 0) { healthScore -= 35; criticalCount++; }
  if (!isHttps) { healthScore -= 12; criticalCount++; }
  if (isNoIndex) { healthScore -= 12; criticalCount++; }
  if (!titleText) { healthScore -= 10; criticalCount++; }
  if (!metaDesc) { healthScore -= 8; criticalCount++; }
  if (h1Count === 0) { healthScore -= 8; criticalCount++; }
  if (mixedContentCount > 0) { healthScore -= 8; criticalCount++; }

  // Warnings (-3 to -6)
  if (titleStatus === 'Warning') { healthScore -= 3; warningCount++; }
  if (descStatus === 'Warning') { healthScore -= 3; warningCount++; }
  if (h1Count > 1) { healthScore -= 3; warningCount++; }
  if (!canonicalTag) { healthScore -= 4; warningCount++; }
  if (missingAltCount > 0) {
    const penalty = Math.min(6, Math.ceil(missingAltCount * 0.8));
    healthScore -= penalty;
    warningCount++;
  }
  if (!hasViewport) { healthScore -= 6; warningCount++; }
  if (isThinContent) { healthScore -= 5; warningCount++; }
  if (insecureInternalLinks > 0) { healthScore -= 4; warningCount++; }
  if (missingDimensionsCount > 3) { healthScore -= 3; warningCount++; }

  // Notices (-1 to -3)
  if (!robotsResult.exists) { healthScore -= 3; noticeCount++; }
  if (!sitemapResult.exists) { healthScore -= 3; noticeCount++; }
  if (!hasSchema) { healthScore -= 4; noticeCount++; }
  if (!hasCompleteOg) { healthScore -= 3; noticeCount++; }
  if (!htmlLang) { healthScore -= 2; noticeCount++; }
  if (emptyAnchorLinks > 0) { healthScore -= 2; noticeCount++; }
  if (!hasFavicon) { healthScore -= 1; noticeCount++; }
  if (securityHeadersScore < 2) { healthScore -= 2; noticeCount++; }

  healthScore = Math.max(10, Math.min(100, healthScore));

  return {
    url: targetUrl,
    finalUrl: finalUrl || targetUrl,
    statusCode,
    responseTimeMs,
    healthScore,
    issuesSummary: {
      critical: criticalCount,
      warnings: warningCount,
      notices: noticeCount
    },
    meta: {
      title: titleText || '(None)',
      titleLength,
      titlePixelWidthEst,
      titleStatus,
      titleIssue,
      description: metaDesc || '(None)',
      descriptionLength: descLength,
      descriptionStatus: descStatus,
      descriptionIssue: descIssue,
      canonical: canonicalTag || '(None)',
      canonicalStatus,
      canonicalIssue,
      isSelfCanonical,
      isCrossDomainCanonical,
      robots: combinedRobots || 'index, follow',
      isNoIndex,
      isNoFollow,
      isNoArchive,
      isNoSnippet,
      xRobotsTag: xRobotsTag || '(None)'
    },
    headings: {
      h1Count,
      h1Status,
      h1Issue,
      primaryH1: h1Texts[0] || '(None)',
      allH1s: h1Texts,
      h2Count,
      h3Count,
      h4Count,
      h5Count,
      h6Count,
      hasHeadingSkips,
      emptyHeadingsCount
    },
    images: {
      total: totalImages,
      missingAlt: missingAltCount,
      emptyAlt: emptyAltCount,
      nextGenFormats: nextGenFormatCount,
      missingDimensions: missingDimensionsCount
    },
    links: {
      total: totalLinks,
      internal: internalLinks,
      external: externalLinks,
      nofollow: nofollowLinks,
      sponsored: sponsoredLinks,
      ugc: ugcLinks,
      emptyAnchors: emptyAnchorLinks,
      insecureInternalLinks
    },
    social: {
      ogTitle: ogTitle || '(None)',
      ogDescription: ogDesc || '(None)',
      ogImage: ogImage || '(None)',
      ogUrl: ogUrl || '(None)',
      ogType: ogType || '(None)',
      ogSiteName: ogSiteName || '(None)',
      twitterCard: twitterCard || '(None)',
      twitterSite: twitterSite || '(None)',
      twitterCreator: twitterCreator || '(None)',
      isComplete: hasCompleteOg,
      hasTwitterCard
    },
    technical: {
      isHttps,
      hasHsts,
      securityHeaders: {
        hsts: hasHsts,
        xContentTypeOptions: hasXContentTypeOptions,
        xFrameOptions: hasXFrameOptions,
        contentSecurityPolicy: hasCsp,
        score: `${securityHeadersScore}/4`
      },
      mixedContentCount,
      hasViewport,
      htmlLang: htmlLang || '(None)',
      hasHreflang,
      charset,
      hasFavicon,
      robotsTxtFound: robotsResult.exists,
      robotsTxtUrl: `${parsedUrl.origin}/robots.txt`,
      hasSitemapInRobots,
      sitemapFound: sitemapResult.exists,
      sitemapUrl: `${parsedUrl.origin}/sitemap.xml`,
      llmsTxtFound: llmsResult.exists,
      llmsTxtUrl: `${parsedUrl.origin}/llms.txt`,
      hasSchema,
      schemaTypes: [...new Set(schemaTypesFound)]
    },
    content: {
      wordCount,
      isThinContent,
      textHtmlRatio: `${textHtmlRatio}%`,
      readingTimeMin: Math.max(1, Math.ceil(wordCount / 200))
    },
    urlStructure: {
      length: targetUrl.length,
      cleanPath,
      hasUppercaseUrl,
      hasUnderscoresUrl,
      hasQueryParams,
      pathDepth,
      isCleanSlug
    },
    rawHtml: body,
    robotsTxtContent: robotsTxtBody
  };
}

function extractSchemaTypes(json, list) {
  if (!json) return;
  if (Array.isArray(json)) {
    json.forEach(item => extractSchemaTypes(item, list));
  } else if (typeof json === 'object') {
    if (json['@type']) {
      if (Array.isArray(json['@type'])) {
        json['@type'].forEach(t => list.push(t));
      } else {
        list.push(json['@type']);
      }
    }
    if (json['@graph'] && Array.isArray(json['@graph'])) {
      json['@graph'].forEach(item => extractSchemaTypes(item, list));
    }
  }
}

/**
 * Fetch raw URL contents, headers and timing with 12s timeout
 */
function fetchUrl(targetUrl) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch (e) {
      return resolve({
        statusCode: 0,
        headers: {},
        body: '',
        responseTimeMs: 0,
        finalUrl: targetUrl
      });
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const req = client.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) PageSpeedReportBot/2.0 (Semrush-Compatible Site Audit Crawler)',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      },
      timeout: 12000
    }, (res) => {
      let body = '';
      const statusCode = res.statusCode || 200;
      const headers = res.headers || {};

      // Handle redirect chain tracking
      if ([301, 302, 307, 308].includes(statusCode) && headers.location) {
        try {
          const redirectUrl = new URL(headers.location, targetUrl).href;
          req.destroy();
          return fetchUrl(redirectUrl).then(resolve);
        } catch (_) {}
      }

      res.on('data', chunk => {
        body += chunk;
        if (body.length > 5000000) { // Max 5MB to prevent memory exhaustion
          req.destroy();
        }
      });

      res.on('end', () => {
        resolve({
          statusCode,
          headers,
          body,
          responseTimeMs: Date.now() - startTime,
          finalUrl: targetUrl
        });
      });
    });

    req.on('error', () => {
      resolve({
        statusCode: 0,
        headers: {},
        body: '',
        responseTimeMs: Date.now() - startTime,
        finalUrl: targetUrl
      });
    });

    req.setTimeout(12000, () => {
      req.destroy();
      resolve({
        statusCode: 408,
        headers: {},
        body: '',
        responseTimeMs: 12000,
        finalUrl: targetUrl
      });
    });
  });
}

module.exports = {
  auditSEO
};
