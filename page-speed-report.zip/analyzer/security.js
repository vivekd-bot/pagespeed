const { URL } = require('url');
const net = require('net');

/**
 * Enterprise DevSecOps & AppSec Guard for Web Scrapers
 * Protects against:
 * 1. SSRF (Server-Side Request Forgery) - Blocks localhost, 127.0.0.1, 169.254.169.254 (Cloud Metadata), RFC1918 Private IPs
 * 2. Protocol Smuggling - Restricts to strictly http: and https: (rejects file://, gopher://, ftp://, ldap://)
 * 3. IP Obfuscation - Rejects hex/octal/decimal representations of loopback/private IPs
 * 4. Resource Exhaustion (DoS) - Enforces URL length and batch size limits
 */

// Cloud metadata and special dangerous hostnames
const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'metadata.google.internal',
  'metadata',
  'instance-data'
]);

/**
 * Check whether an IP string belongs to private, loopback, or link-local ranges
 */
function isPrivateOrReservedIp(ip) {
  if (!ip) return false;

  // IPv4 Loopback: 127.0.0.0/8
  if (/^127\./.test(ip)) return true;

  // IPv4 Zero: 0.0.0.0/8
  if (/^0\./.test(ip) || ip === '0.0.0.0') return true;

  // Cloud Metadata & Link-Local: 169.254.0.0/16
  if (/^169\.254\./.test(ip)) return true;

  // Private RFC 1918:
  // 10.0.0.0/8
  if (/^10\./.test(ip)) return true;
  // 192.168.0.0/16
  if (/^192\.168\./.test(ip)) return true;
  // 172.16.0.0/12 (172.16.x.x - 172.31.x.x)
  const match172 = ip.match(/^172\.(\d+)\./);
  if (match172) {
    const secondOctet = parseInt(match172[1], 10);
    if (secondOctet >= 16 && secondOctet <= 31) return true;
  }

  // IPv6 checks
  if (ip === '::1' || ip === '::' || ip.startsWith('fe80:') || ip.startsWith('fc00:') || ip.startsWith('fd00:')) {
    return true;
  }

  return false;
}

/**
 * Validates a target URL against SSRF and protocol manipulation
 * @param {string} rawUrl
 * @returns {{ safe: boolean, error?: string, parsed?: URL }}
 */
function validateSafeUrl(rawUrl) {
  if (typeof rawUrl !== 'string' || !rawUrl.trim()) {
    return { safe: false, error: 'Empty or invalid URL input' };
  }

  const trimmed = rawUrl.trim();
  if (trimmed.length > 2048) {
    return { safe: false, error: 'URL exceeds maximum safe length (2,048 chars)' };
  }

  // Reject non-http protocols if a scheme is present
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed)) {
    if (!/^https?:\/\//i.test(trimmed)) {
      return { safe: false, error: 'Disallowed protocol (only http:// and https:// permitted)' };
    }
  }

  const normalized = trimmed.startsWith('http://') || trimmed.startsWith('https://')
    ? trimmed
    : `https://${trimmed}`;

  let parsed;
  try {
    parsed = new URL(normalized);
  } catch (err) {
    return { safe: false, error: 'Malformed URL syntax' };
  }

  // 1. Protocol Restriction
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { safe: false, error: `Disallowed protocol: ${parsed.protocol} (only HTTP/HTTPS allowed)` };
  }

  const hostname = parsed.hostname.toLowerCase().trim();

  // 2. Reject blocked hostnames
  if (BLOCKED_HOSTNAMES.has(hostname) || hostname.endsWith('.localhost')) {
    return { safe: false, error: `Access to internal host '${hostname}' is forbidden (SSRF protection)` };
  }

  // 3. Reject integer / octal / hex encoded IP addresses (e.g., http://2130706433 or 0x7f000001)
  if (/^\d+$/.test(hostname) || /^0x[0-9a-f]+$/i.test(hostname)) {
    return { safe: false, error: 'Numeric or hex-encoded IP addresses are blocked (SSRF protection)' };
  }

  // 4. Check if direct IP literal is private/reserved
  if (net.isIP(hostname)) {
    if (isPrivateOrReservedIp(hostname)) {
      return { safe: false, error: `Access to private/local network address (${hostname}) is blocked (SSRF protection)` };
    }
  }

  return { safe: true, parsed };
}

/**
 * Filter an array of URLs for batch processing
 * @param {string[]} urls
 * @param {number} maxAllowed
 * @returns {{ validUrls: string[], rejected: { url: string, reason: string }[] }}
 */
function sanitizeBatchUrls(urls, maxAllowed = 1000) {
  const validUrls = [];
  const rejected = [];
  const seen = new Set();

  for (const raw of urls) {
    if (validUrls.length >= maxAllowed) {
      rejected.push({ url: raw, reason: `Batch exceeded maximum limit of ${maxAllowed} URLs` });
      continue;
    }

    const { safe, error, parsed } = validateSafeUrl(raw);
    if (!safe) {
      rejected.push({ url: raw, reason: error });
      continue;
    }

    const cleanHref = parsed.href;
    const lower = cleanHref.toLowerCase();
    if (!seen.has(lower)) {
      seen.add(lower);
      validUrls.push(cleanHref);
    }
  }

  return { validUrls, rejected };
}

module.exports = {
  validateSafeUrl,
  sanitizeBatchUrls,
  isPrivateOrReservedIp
};
