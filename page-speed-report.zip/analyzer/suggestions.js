/**
 * Synthesizes performance, SEO and AEO findings into prioritized, actionable suggestions
 * with real-time code fixes and implementation instructions (10+ Years Veteran Standards).
 */
function generateSuggestions(url, desktopData, mobileData, seoData, aeoData = null) {
  const suggestions = [];

  // ----------------------------------------------------
  // 1. PERFORMANCE / CORE WEB VITALS (Desktop & Mobile)
  // ----------------------------------------------------
  if (desktopData.performanceScore < 60 || mobileData.performanceScore < 50) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'Performance',
      issue: 'Poor Overall PageSpeed Score',
      currentStatus: `Desktop: ${desktopData.performanceScore}/100, Mobile: ${mobileData.performanceScore}/100`,
      recommendation: 'Implement server-level caching (Redis/Varnish), configure a Global CDN (Cloudflare/Fastly), and audit heavy third-party tracking tags.',
      impact: 'High - Directly improves Google PageSpeed ranking factor and reduces bounce rates.',
      codeSnippet: `// Cloudflare / CDN Cache-Control header:
Cache-Control: public, max-age=31536000, immutable`
    });
  }

  // TTFB (Time to First Byte)
  const desktopTtfbNum = parseInt(desktopData.ttfb, 10);
  if (!isNaN(desktopTtfbNum) && desktopTtfbNum > 600) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'Performance',
      issue: 'High Server Response Time (TTFB > 600ms)',
      currentStatus: `TTFB is ${desktopData.ttfb}`,
      recommendation: 'Target TTFB under 200ms. Upgrade hosting resources, enable opcode caching (PHP OPcache / Node cluster), optimize slow SQL queries, and serve static HTML pages via Edge CDN.',
      impact: 'High - Accelerates all downstream Core Web Vitals (FCP, LCP).',
      codeSnippet: `// Nginx FastCGI/Proxy Microcache snippet:
proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=PAGE_CACHE:100m inactive=60m;
proxy_cache PAGE_CACHE;
proxy_cache_valid 200 301 302 10m;`
    });
  }

  // LCP (Largest Contentful Paint)
  const lcpNum = parseFloat(mobileData.lcp);
  if (!isNaN(lcpNum) && lcpNum > 2.5) {
    suggestions.push({
      url,
      priority: lcpNum > 4.0 ? 'Critical' : 'Warning',
      category: 'Performance',
      issue: 'Slow Largest Contentful Paint (LCP > 2.5s)',
      currentStatus: `Mobile LCP is ${mobileData.lcp} (Threshold: <= 2.5s for Good)`,
      recommendation: 'Preload hero images with fetchpriority="high", inline critical above-the-fold CSS, and defer non-critical JavaScript.',
      impact: 'High - Core Web Vital ranking metric for mobile search.',
      codeSnippet: `<!-- Preload hero banner for instant LCP -->
<link rel="preload" as="image" href="/path/to/hero.webp" fetchpriority="high">`
    });
  }

  // CLS (Cumulative Layout Shift)
  const clsNum = parseFloat(mobileData.cls);
  if (!isNaN(clsNum) && clsNum > 0.1) {
    suggestions.push({
      url,
      priority: clsNum > 0.25 ? 'Critical' : 'Warning',
      category: 'Performance',
      issue: 'High Cumulative Layout Shift (CLS > 0.1)',
      currentStatus: `Mobile CLS is ${mobileData.cls} (Target: <= 0.1)`,
      recommendation: 'Always specify explicit width and height attributes on <img> and <iframe> elements to reserve space before assets load. Avoid inserting dynamic DOM elements above existing content.',
      impact: 'Medium - Eliminates sudden page shifting and prevents accidental user clicks.',
      codeSnippet: `<!-- Always specify explicit dimensions or aspect-ratio -->
<img src="banner.webp" width="1200" height="630" style="aspect-ratio: 1200 / 630; width: 100%; height: auto;" alt="Banner">`
    });
  }

  // Mobile Diagnostics
  if (mobileData.diagnostics && mobileData.diagnostics.length > 0) {
    mobileData.diagnostics.forEach(diag => {
      let codeSnippet = '';
      if (diag.id === 'text-compression' || diag.id === 'uses-text-compression') {
        codeSnippet = `# Apache (.htaccess) Gzip Compression:
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json image/svg+xml
</IfModule>`;
      } else if (diag.id === 'render-blocking-resources') {
        codeSnippet = `<!-- Defer non-critical scripts -->
<script src="bundle.js" defer></script>`;
      } else if (diag.id === 'modern-image-formats') {
        codeSnippet = `<!-- Modern Responsive WebP / AVIF with Fallback -->
<picture>
  <source srcset="image.avif" type="image/avif">
  <source srcset="image.webp" type="image/webp">
  <img src="image.jpg" alt="Optimized visual" loading="lazy">
</picture>`;
      }

      suggestions.push({
        url,
        priority: 'Warning',
        category: 'Performance',
        issue: diag.title,
        currentStatus: diag.savings || 'Unoptimized resource detected',
        recommendation: diag.description,
        impact: 'Medium - Optimizes mobile data bandwidth and CPU rendering.',
        codeSnippet: codeSnippet || undefined
      });
    });
  }

  // ----------------------------------------------------
  // 2. SEO & SEMRUSH-STYLE TECHNICAL AUDIT
  // ----------------------------------------------------

  // HTTPS Security
  if (!seoData.technical.isHttps) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'Technical SEO',
      issue: 'Website Not Using Secure HTTPS Protocol',
      currentStatus: 'Served over unencrypted HTTP',
      recommendation: 'Install a TLS/SSL certificate and configure an HTTP to HTTPS 301 redirect for all traffic.',
      impact: 'Critical - Google flags unencrypted sites as "Not Secure" and demotes them in rankings.',
      codeSnippet: `// Nginx 301 Permanent Redirect to HTTPS
server {
  listen 80;
  server_name example.com www.example.com;
  return 301 https://$host$request_uri;
}`
    });
  }

  // Mixed Content
  if (seoData.technical.mixedContentCount > 0) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'Technical SEO',
      issue: `Mixed Content Detected (${seoData.technical.mixedContentCount} insecure HTTP assets)`,
      currentStatus: `${seoData.technical.mixedContentCount} scripts, styles, or images loaded via http:// on an https:// page`,
      recommendation: 'Update all asset URLs to use relative paths or https://. Modern browsers block HTTP passive and active mixed content by default.',
      impact: 'Critical - Prevents browser security warnings and broken styling.',
      codeSnippet: `<!-- Upgrade Insecure Requests via CSP header -->
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">`
    });
  }

  // HSTS Header
  if (seoData.technical.isHttps && !seoData.technical.hasHsts) {
    suggestions.push({
      url,
      priority: 'Optimization',
      category: 'Technical SEO',
      issue: 'Missing Strict-Transport-Security (HSTS) Header',
      currentStatus: 'HSTS header not present in HTTP response',
      recommendation: 'Enable HTTP Strict Transport Security (HSTS) with a max-age of at least 1 year (31536000) to protect against SSL-stripping man-in-the-middle attacks.',
      impact: 'Medium - Hardens TLS security and qualifies for browser HSTS preload list.',
      codeSnippet: `// Add HSTS Header in Web Server:
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
    });
  }

  // Insecure Internal Links
  if (seoData.links.insecureInternalLinks > 0) {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'Technical SEO',
      issue: `${seoData.links.insecureInternalLinks} Insecure HTTP Internal Links`,
      currentStatus: 'Internal hyperlinks point to http:// instead of https://',
      recommendation: 'Update all internal links in the database and HTML templates to use https:// or root-relative paths (/path). Eliminates unnecessary 301 redirects and preserves crawl budget.',
      impact: 'Medium - Saves internal redirect hops and preserves page authority.'
    });
  }

  // Noindex Directive
  if (seoData.meta.isNoIndex) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'Indexability',
      issue: 'Page Has "noindex" Directive',
      currentStatus: `Robots meta / X-Robots-Tag: "${seoData.meta.robots}"`,
      recommendation: 'Remove "noindex" from your meta robots tag and X-Robots-Tag header if this page is intended for public organic search visibility.',
      impact: 'Critical - Completely blocks Google, Bing, and other search engines from indexing this page.'
    });
  }

  // Title Tag
  if (!seoData.meta.title || seoData.meta.title === '(None)') {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'On-Page SEO',
      issue: 'Missing <title> Tag Completely',
      currentStatus: 'No <title> element found inside <head>',
      recommendation: 'Add a distinct, compelling <title> tag between 50-60 characters including the primary target keyword and brand name.',
      impact: 'Critical - The single most influential on-page SEO ranking signal.',
      codeSnippet: `<title>Primary Target Keyword | Compelling Value Proposition - Brand Name</title>`
    });
  } else if (seoData.meta.titleStatus === 'Warning') {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'On-Page SEO',
      issue: `Title Length Optimization (${seoData.meta.titleLength} characters)`,
      currentStatus: `Current: "${seoData.meta.title}"`,
      recommendation: seoData.meta.titleLength < 30
        ? 'Expand title to 50-60 characters with secondary keywords to maximize SERP click-through rate.'
        : 'Shorten title to under 60 characters (~580px width) to avoid truncation with an ellipsis in Google SERP.',
      impact: 'Medium - Enhances visibility and SERP click-through rates (CTR).'
    });
  }

  // Meta Description
  if (!seoData.meta.description || seoData.meta.description === '(None)') {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'On-Page SEO',
      issue: 'Missing Meta Description',
      currentStatus: 'No <meta name="description"> tag found',
      recommendation: 'Write an enticing 140-160 character meta description that summarizes the page content, features secondary keywords, and includes a clear call to action.',
      impact: 'Medium - Drives higher click-through rates (CTR) from search results.',
      codeSnippet: `<meta name="description" content="Discover how [Product/Service] helps you achieve [Benefit]. Read our comprehensive guide with key examples, benchmarks, and best practices.">`
    });
  }

  // Canonical Tag
  if (!seoData.meta.canonical || seoData.meta.canonical === '(None)') {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'Technical SEO',
      issue: 'Missing Canonical Tag',
      currentStatus: 'No <link rel="canonical"> specified',
      recommendation: 'Add a self-referential canonical tag to specify the authoritative version of this page and prevent duplicate content penalties from URL query parameters.',
      impact: 'Medium - Prevents index dilution and duplicate content issues.',
      codeSnippet: `<link rel="canonical" href="${url}">`
    });
  }

  // H1 Heading
  if (seoData.headings.h1Count === 0) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'On-Page SEO',
      issue: 'Missing Primary H1 Heading',
      currentStatus: '0 <h1> tags detected on the page',
      recommendation: 'Add exactly one descriptive <h1> tag near the top of the body containing your primary keyword to define the main topic of the page.',
      impact: 'High - Strong semantic signal for search engines and screen readers.',
      codeSnippet: `<h1>The Definitive Guide to [Your Primary Keyword]</h1>`
    });
  } else if (seoData.headings.h1Count > 1) {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'On-Page SEO',
      issue: `Multiple H1 Headings (${seoData.headings.h1Count} Found)`,
      currentStatus: `Detected ${seoData.headings.h1Count} H1 tags: ${seoData.headings.allH1s.map(h => `"${h}"`).join(', ')}`,
      recommendation: 'Consolidate to a single primary <h1> per page. Convert secondary H1 elements into <h2> subheadings to establish a clean semantic hierarchy.',
      impact: 'Medium - Clarifies semantic hierarchy for search crawlers.'
    });
  }

  // Heading Skips
  if (seoData.headings.hasHeadingSkips) {
    suggestions.push({
      url,
      priority: 'Optimization',
      category: 'On-Page SEO',
      issue: 'Skipped Heading Levels in Semantic Hierarchy',
      currentStatus: 'Page jumps from H1 directly to H3/H4 without intervening H2 subheadings',
      recommendation: 'Maintain a strict sequential heading hierarchy (H1 -> H2 -> H3 -> H4). Never skip levels purely for visual styling.',
      impact: 'Low - Improves semantic accessibility and document outline structure.'
    });
  }

  // Image Dimensions (CLS hazard)
  if (seoData.images.missingDimensions > 0) {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'Performance & Accessibility',
      issue: `${seoData.images.missingDimensions} Images Missing Explicit Width/Height Attributes`,
      currentStatus: `${seoData.images.missingDimensions} of ${seoData.images.total} images do not define dimensions`,
      recommendation: 'Add explicit width="" and height="" attributes or CSS aspect-ratio on all <img> tags to reserve layout space and eliminate Cumulative Layout Shift (CLS).',
      impact: 'High for Core Web Vitals - Directly prevents layout jumps and CLS degradation.',
      codeSnippet: `<img src="photo.webp" width="800" height="450" alt="Description" style="aspect-ratio: 16/9; width: 100%; height: auto;">`
    });
  }

  // Image Alt Tags
  if (seoData.images.missingAlt > 0) {
    suggestions.push({
      url,
      priority: seoData.images.missingAlt > 5 ? 'Warning' : 'Optimization',
      category: 'On-Page SEO',
      issue: `${seoData.images.missingAlt} Images Missing ALT Attributes`,
      currentStatus: `${seoData.images.missingAlt} of ${seoData.images.total} images have no alt text`,
      recommendation: 'Add descriptive, keyword-rich alt="..." attributes to all content images for SEO and screen-reader accessibility (WCAG). Use alt="" for purely decorative icons.',
      impact: 'Medium - Improves Google Image Search rankings and accessibility compliance.',
      codeSnippet: `<img src="product.jpg" alt="Detailed description with target keyword" loading="lazy">`
    });
  }

  // Mobile Viewport
  if (!seoData.technical.hasViewport) {
    suggestions.push({
      url,
      priority: 'Critical',
      category: 'Technical SEO',
      issue: 'Missing Mobile Viewport Meta Tag',
      currentStatus: 'No <meta name="viewport"> tag detected',
      recommendation: 'Add a standard responsive viewport meta tag to the <head> of your HTML.',
      impact: 'Critical - Required for mobile-friendly indexing by Google Mobile-First Indexing.',
      codeSnippet: `<meta name="viewport" content="width=device-width, initial-scale=1.0">`
    });
  }

  // Schema Markup / Structured Data
  if (!seoData.technical.hasSchema) {
    suggestions.push({
      url,
      priority: 'Optimization',
      category: 'Structured Data & Social',
      issue: 'No Schema.org Structured Data Detected',
      currentStatus: '0 JSON-LD or Microdata schemas found',
      recommendation: 'Implement JSON-LD Schema markup (e.g. WebSite, Organization, Article, LocalBusiness) to become eligible for Google Rich Snippets in SERP.',
      impact: 'Medium - Enhances search visibility and rich result appearance in Google.',
      codeSnippet: `<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "Website Name",
  "url": "${url}"
}
</script>`
    });
  }

  // Thin Content
  if (seoData.content.isThinContent) {
    suggestions.push({
      url,
      priority: 'Warning',
      category: 'On-Page SEO',
      issue: 'Thin Content Detected (Low Word Count)',
      currentStatus: `Only ${seoData.content.wordCount} words detected on page (under 300 words)`,
      recommendation: 'Expand page content to at least 500-1000 words covering user intent comprehensively, with relevant subheadings, FAQs, and topic depth.',
      impact: 'High - Thin pages struggle to rank against thorough, authoritative competitor content.'
    });
  }

  // ----------------------------------------------------
  // 3. AEO (ANSWER ENGINE OPTIMIZATION) & AI SEARCH FIXES
  // ----------------------------------------------------
  if (aeoData) {
    // FAQPage Schema
    if (!aeoData.schemas.hasFaqSchema) {
      suggestions.push({
        url,
        priority: 'Critical',
        category: 'AEO (AI Search)',
        issue: 'Missing FAQPage Schema for AI Overviews & ChatGPT',
        currentStatus: '0 FAQPage JSON-LD schemas detected',
        recommendation: 'Implement FAQPage structured data so Google AI Overviews, Perplexity, and ChatGPT can parse and quote your direct question-and-answer pairs.',
        impact: 'Critical for AEO - Doubles likelihood of being featured in AI Overviews and Rich Results.',
        codeSnippet: `<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is the primary benefit of this service/product?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Provide a direct, concise 40 to 60 word answer explaining the primary value proposition clearly without fluff."
      }
    },
    {
      "@type": "Question",
      "name": "How does it work?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Explain the 3-step process clearly so AI search engines can ingest and cite it in conversational answers."
      }
    }
  ]
}
</script>`
      });
    }

    // Speakable Schema for Voice & Conversational AI
    if (!aeoData.schemas.hasSpeakableSchema) {
      suggestions.push({
        url,
        priority: 'Optimization',
        category: 'AEO (AI Search)',
        issue: 'Missing Speakable Schema for Voice Assistants & AI Engines',
        currentStatus: 'No SpeakableSpecification markup found',
        recommendation: 'Add Speakable schema pointing to key summary paragraphs or headlines so Siri, Google Assistant, and voice AI bots can read your content aloud.',
        impact: 'High for Voice Search - Directly powers voice answers and AI summary audio output.',
        codeSnippet: `<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "${seoData.meta.title || 'Page Title'}",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".ai-summary", "h1", ".direct-answer"]
  },
  "url": "${url}"
}
</script>`
      });
    }

    // Question Headings & 40-60 Word Direct Answer Chunks
    if (aeoData.qaAnalysis.totalQuestions === 0) {
      suggestions.push({
        url,
        priority: 'Critical',
        category: 'AEO (AI Search)',
        issue: 'No Conversational Question Headings (What/How/Why)',
        currentStatus: '0 question-based H2/H3 headings found',
        recommendation: 'Format at least 2-3 subheadings as natural language questions (e.g., "What is [Topic]?", "How does [Topic] work?", "Why choose [Brand]?"), immediately followed by a 40-60 word definitive answer.',
        impact: 'Critical for AEO - LLMs prioritize matching exact conversational user search prompts.',
        codeSnippet: `<!-- Optimal AEO Content Chunking Structure -->
<h2>What is [Primary Keyword / Topic]?</h2>
<p class="direct-answer">
  [Topic] is [clear definition in 40-60 words]. It helps users achieve [key outcome] by [core mechanism], delivering [measurable benefit].
</p>`
      });
    } else if (aeoData.summary.optimalAnswersCount === 0) {
      suggestions.push({
        url,
        priority: 'Warning',
        category: 'AEO (AI Search)',
        issue: 'Direct Answers Under Question Headings Are Not 40-60 Words',
        currentStatus: `${aeoData.qaAnalysis.totalQuestions} questions found, but 0 have optimal 40-60 word answer length`,
        recommendation: 'Refactor the immediate paragraph following each question heading to be a concise 40-60 word definition. Long, rambling answers are discarded by AI engines in favor of concise competitor snippets.',
        impact: 'High for AEO - Matches LLM extract length limits for AI Overviews.',
        codeSnippet: `<!-- Keep the first paragraph after H2 concise (40-60 words) -->
<h2>How much does [Product] cost?</h2>
<p>
  Pricing starts at $X per month for the starter tier and scales up to $Y for enterprise features. All plans include full access to core capabilities, customer support, and automatic updates with no hidden setup fees.
</p>`
      });
    }

    // AI Crawlers in robots.txt
    if (aeoData.summary.aiBotsBlockedCount > 0) {
      const blockedNames = aeoData.aiBotStatus.filter(b => !b.allowed).map(b => b.bot).join(', ');
      suggestions.push({
        url,
        priority: 'Critical',
        category: 'AEO (AI Search)',
        issue: `AI Search Crawlers Blocked in robots.txt (${blockedNames})`,
        currentStatus: `${aeoData.summary.aiBotsBlockedCount} AI bots disallowed`,
        recommendation: `Allow OpenAI (GPTBot, ChatGPT-User) and PerplexityBot in robots.txt if you want your site to be cited and recommended in AI Search. Blocking them renders your site invisible to ChatGPT Search and Perplexity.`,
        impact: 'Critical for AEO - Ensures AI search engines can index, cite, and link back to your domain.',
        codeSnippet: `# robots.txt: Explicitly allow AI Search Crawlers:
User-agent: GPTBot
Allow: /

User-agent: ChatGPT-User
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: ClaudeBot
Allow: /`
      });
    }

    // llms.txt standard
    if (!aeoData.summary.llmsTxtFound) {
      suggestions.push({
        url,
        priority: 'Optimization',
        category: 'AEO (AI Search)',
        issue: 'Missing /llms.txt Standard Documentation File',
        currentStatus: '404 Not Found at /llms.txt',
        recommendation: 'Deploy an /llms.txt markdown file at the root of your domain. This emerging standard provides concise structured context for LLM agents, ChatGPT, and Claude to understand your platform instantly.',
        impact: 'High for LLM Retrieval - Provides direct curated context for AI reasoning models.',
        codeSnippet: `# /llms.txt example:
# [Company Name]
> Concise 2-sentence summary of what your company or service does.

## Core Capabilities
- [Service 1]: https://example.com/service-1
- [Pricing]: https://example.com/pricing
- [API / Docs]: https://example.com/docs`
      });
    }

    // sameAs Entity Authority Links
    if (!aeoData.schemas.hasSameAs) {
      suggestions.push({
        url,
        priority: 'Optimization',
        category: 'AEO (AI Search)',
        issue: 'Missing sameAs Entity Authority Links in Organization Schema',
        currentStatus: 'No Wikidata, Wikipedia, Crunchbase, or official social links in schema',
        recommendation: 'Add "sameAs" array to your Organization or Person schema linking to Wikipedia, Wikidata, LinkedIn, Crunchbase, and GitHub. LLMs use these authoritative links to disambiguate and ground entities in knowledge graphs.',
        impact: 'High for Entity Disambiguation - Connects your brand to Google Knowledge Graph and OpenAI entity indices.',
        codeSnippet: `<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Brand Name",
  "url": "${url}",
  "sameAs": [
    "https://www.wikidata.org/wiki/Q...",
    "https://www.linkedin.com/company/brand",
    "https://en.wikipedia.org/wiki/Brand"
  ]
}
</script>`
      });
    }

    // Sentence Length / Hallucination Risk
    if (aeoData.readability?.avgWordsPerSentence > 25) {
      suggestions.push({
        url,
        priority: 'Warning',
        category: 'AEO (AI Search)',
        issue: 'High Sentence Complexity (Avg Words > 25)',
        currentStatus: `Average sentence length is ${aeoData.readability.avgWordsPerSentence} words`,
        recommendation: 'Break long, compound sentences into shorter, declarative statements (under 20 words per sentence). Long complex sentences cause LLMs to misinterpret modifiers and trigger factual hallucinations.',
        impact: 'Medium for AI Summaries - Minimizes hallucination risk and improves readability.'
      });
    }

    // Comparison Tables & Step-by-Step Lists
    if (aeoData.scannability.tablesCount === 0) {
      suggestions.push({
        url,
        priority: 'Optimization',
        category: 'AEO (AI Search)',
        issue: 'Missing Comparison / Data Table for AI Ingestion',
        currentStatus: '0 <table> tags found on page',
        recommendation: 'Add comparison or specification tables with clear <th> and <td> cells. LLMs ingest tables to answer comparison queries (e.g. "[Brand] vs Competitor", "Feature Matrix", "Pricing Comparison").',
        impact: 'High for AEO - Tables are cited in over 40% of comparative AI Overviews.',
        codeSnippet: `<table>
  <thead>
    <tr><th>Feature</th><th>[Your Solution]</th><th>Traditional Alternative</th></tr>
  </thead>
  <tbody>
    <tr><td>Performance Score</td><td>95+</td><td>60-70</td></tr>
    <tr><td>AI Readiness (AEO)</td><td>Fully Optimized</td><td>Unoptimized</td></tr>
  </tbody>
</table>`
      });
    }

    // EEAT Author Byline for AI Trust
    if (!aeoData.eeat.hasAuthorByline) {
      suggestions.push({
        url,
        priority: 'Warning',
        category: 'AEO (AI Search)',
        issue: 'Missing Author Attribution / EEAT Byline',
        currentStatus: 'No author markup or byline detected',
        recommendation: 'Add an explicit author byline with author name, professional credentials, and link to an author bio page. AI engines evaluate author expertise before citing medical, technical, or financial answers.',
        impact: 'High for AEO & EEAT - Establishes verifiable human subject-matter authority.',
        codeSnippet: `<div class="author-byline" itemprop="author" itemscope itemtype="https://schema.org/Person">
  Written by <span itemprop="name">Jane Doe</span>, <span itemprop="jobTitle">Senior SEO & Performance Architect</span>
  <meta itemprop="url" content="${url.replace(/\/+$/, '')}/authors/jane-doe">
</div>`
      });
    }
  }

  return suggestions;
}

module.exports = {
  generateSuggestions
};
