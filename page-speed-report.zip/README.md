# Page Speed Report & SEO Semrush Analyzer

A high-performance website scraper and audit suite built with a **Modern Local Web UI**, **Google PageSpeed Insights Engine**, **Semrush-style Technical SEO Crawler**, **Prioritized Action Plan Generator**, and **1-Click Multi-Tab Excel (.xlsx) & Word Document (.docx) Exporting**.

---

## 🌟 Key Features

1. **Bulk Website Scraper & Analyzer**:
   - Paste single or multiple URLs (one per line) to audit entire batches of websites simultaneously.
   - Dual-engine architecture: Uses official **Google PageSpeed Insights / Lighthouse API** with an automatic, zero-configuration local probe fallback when offline or rate-limited.

2. **🖥️ Tab 1: Desktop View Report**:
   - Desktop Performance Score (0–100)
   - Core Web Vitals: First Contentful Paint (FCP), Largest Contentful Paint (LCP), Cumulative Layout Shift (CLS), Total Blocking Time (TBT), Speed Index, Time to First Byte (TTFB).
   - Page payload size (KB), network request count, and render-blocking diagnostics.

3. **📱 Tab 2: Mobile View Report**:
   - Mobile Performance Score (0–100) calibrated for mobile devices and 4G networks.
   - Mobile Core Web Vitals (FCP, LCP, CLS, TBT, TTFB).
   - Mobile-friendliness verification: Viewport meta tag presence and responsive rendering.

4. **🔍 Tab 3: SEO Semrush-Style Audit**:
   - **Overall SEO Health Score** (0–100) using weighted penalty calculations similar to Semrush Site Audit.
   - **Meta Tag Inspection**: Title tag length (50–60 chars recommendation), description length (120–160 chars), duplicate checks.
   - **Headings Structure**: H1 presence & uniqueness (exactly one primary H1), H2–H6 hierarchy.
   - **Technical SEO**: Canonical tags, `robots.txt` verification, XML Sitemap detection (`/sitemap.xml`), HTTPS/SSL security, HSTS, meta robots (`index/noindex`, `follow/nofollow`).
   - **Images Audit**: Total images, missing `alt` attributes, modern format adoption (WebP/AVIF).
   - **Link Analysis**: Internal vs. External links count, nofollow links, empty anchor text check.
   - **Structured Data & Social**: JSON-LD Schema.org detection, Open Graph (`og:title`, `og:image`, `og:description`), Twitter Card tags.
   - **Content Analysis**: Word count, text-to-HTML ratio, and estimated reading time.

5. **🤖 Tab 4: AEO (Answer Engine Optimization) & AI Search Report**:
   - **AEO Readiness Score** (0–100) & AI Grade (A+ Ready, B Good, C Needs Work, F Unprepared).
   - **AI Bots Crawlability**: Audits `robots.txt` access for `GPTBot`, `ChatGPT-User`, `PerplexityBot`, `Google-Extended` (Gemini), `ClaudeBot`, `CCBot`, `Bytespider`.
   - **Structured Data for AI**: Detects `FAQPage`, `HowTo`, `Speakable` (voice assistants), `Article`, and `Organization` schemas.
   - **Direct Answer Chunks**: Scans for natural question headings (`What is`, `How to`, `Why`) and checks for 40–60 word definitive answer paragraphs.
   - **AI Scannability**: Counts bulleted/numbered lists and structured `<table>` elements essential for LLM extraction.
   - **EEAT Authority & Readability**: Checks for author bylines, date stamps, and computes Flesch Reading Ease score for LLM comprehension.

6. **💡 Tab 5: What Need To Change (Action Plan & Suggestions)**:
   - Prioritized into **Critical (High)**, **Warning (Medium)**, and **Optimization (Low)**.
   - Categorized by Performance, Mobile Usability, On-Page SEO, Technical SEO, and **AEO (AI Search)**.
   - Copyable code snippets for instant fixes: `FAQPage` JSON-LD schema, `Speakable` schema, robots.txt AI bot directives, GZIP configs, and LCP preloads.

7. **📊 Multi-Tab Excel Workbook (.xlsx)**:
   - **Tab 1**: Desktop Page Speed
   - **Tab 2**: Mobile Page Speed
   - **Tab 3**: SEO Semrush Report
   - **Tab 4**: AEO AI Search Report
   - **Tab 5**: What Need To Change
   - Styled with dark slate headers, frozen panes, auto-fit column widths, auto-filters, and color-coded status badges.

8. **📄 Executive Document Report (.docx)**:
   - Ready-to-deliver Word Document (.docx) formatted with executive summary, performance comparison, SEO audit tables, AEO AI readiness matrix, and prioritized remediation plan.

---

## 🚀 How to Run Locally

### Option 1: Double-Click Launcher (Windows)
Double-click `start.bat` inside this folder. It will start the server and automatically open the UI in your default browser at:
`http://localhost:3050`

### Option 2: PowerShell
```powershell
.\start.ps1
```

### Option 3: Terminal Command
```bash
node server.js
```
Then visit `http://localhost:3050` in your web browser.

---

## 📁 Project Structure

```
page-speed-report/
├── analyzer/
│   ├── pagespeed.js     # Desktop & Mobile PageSpeed analyzer (PSI + fallback)
│   ├── seo.js           # Semrush-style comprehensive crawler and SEO auditor
│   └── suggestions.js   # Actionable remediation & fix recommendations generator
├── generators/
│   ├── excel.js         # 4-Tab Excel (.xlsx) workbook generator with styling
│   └── docx.js          # Executive Word Document (.docx) report generator
├── public/
│   └── index.html       # Modern Local Web Dashboard (Tailwind CSS, KPIs, live tabs)
├── package.json         # Dependencies & scripts
├── server.js            # Express backend & REST API endpoints
├── start.bat            # Windows 1-click batch launcher
├── start.ps1            # Windows PowerShell launcher
└── README.md            # Documentation
```

---

## 🛠️ API Endpoints

- `GET  /api/health` - Health status of scraper
- `POST /api/analyze` - Accepts `{ urls: string[], apiKey?: string }` and returns full audit
- `POST /api/export/excel` - Generates and downloads styled 4-tab Excel `.xlsx` file
- `POST /api/export/docx` - Generates and downloads structured Word `.docx` file
