const docx = require('docx');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, HeadingLevel, BorderStyle } = docx;

/**
 * Generate a professional Word (.docx) audit report
 */
async function generateDocxReport(results) {
  const sections = [];

  const tableBorder = {
    top: { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" },
    bottom: { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" },
    left: { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" },
    right: { style: BorderStyle.SINGLE, size: 1, color: "CBD5E1" }
  };

  const headerCellShading = { fill: "1E293B" }; // Slate 800
  const zebraShading = { fill: "F8FAFC" };

  const children = [];

  // Title & Header
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 200, after: 100 },
      children: [
        new TextRun({
          text: "PAGE SPEED & SEO AUDIT REPORT",
          bold: true,
          size: 40,
          color: "0F172A",
          font: "Segoe UI"
        })
      ]
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 300 },
      children: [
        new TextRun({
          text: "Comprehensive Desktop, Mobile, Semrush-Style Technical SEO & Action Plan",
          italics: true,
          size: 22,
          color: "64748B",
          font: "Segoe UI"
        })
      ]
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [
        new TextRun({
          text: `Report Generated: ${new Date().toLocaleDateString('en-US', { dateStyle: 'full' })} | Total Pages Audited: ${results.length}`,
          bold: true,
          size: 18,
          color: "3B82F6",
          font: "Segoe UI"
        })
      ]
    })
  );

  // Executive Summary Section
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 300, after: 150 },
      children: [
        new TextRun({ text: "1. Executive Summary & Health Dashboard", bold: true, size: 28, color: "1E293B", font: "Segoe UI" })
      ]
    })
  );

  // Summary Table
  const summaryHeaderRow = new TableRow({
    children: [
      createHeaderCell("Target URL", 28),
      createHeaderCell("Desktop", 12),
      createHeaderCell("Mobile", 12),
      createHeaderCell("SEO Score", 12),
      createHeaderCell("AEO Score", 14),
      createHeaderCell("Total Issues", 22)
    ]
  });

  const summaryRows = [summaryHeaderRow];
  results.forEach((item, index) => {
    const isEven = index % 2 === 0;
    const shading = isEven ? null : zebraShading;
    const issues = item.suggestions || [];
    const critCount = issues.filter(x => x.priority === 'Critical').length;
    const warnCount = issues.filter(x => x.priority === 'Warning').length;
    const aeoScore = item.aeo?.aeoScore || 50;

    summaryRows.push(new TableRow({
      children: [
        createCell(item.url, 28, false, shading),
        createScoreCell(`${item.desktop.performanceScore} / 100`, 12, item.desktop.performanceScore, shading),
        createScoreCell(`${item.mobile.performanceScore} / 100`, 12, item.mobile.performanceScore, shading),
        createScoreCell(`${item.seo.healthScore} / 100`, 12, item.seo.healthScore, shading),
        createScoreCell(`${aeoScore} / 100`, 14, aeoScore, shading),
        createCell(`${critCount} Crit, ${warnCount} Warn (${issues.length} Tot)`, 22, false, shading)
      ]
    }));
  });

  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: summaryRows
  }));

  // Section 2: Desktop Performance Analysis
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 150 },
      children: [
        new TextRun({ text: "2. Desktop Page Speed & Core Web Vitals", bold: true, size: 28, color: "1E293B", font: "Segoe UI" })
      ]
    })
  );

  const desktopHeaderRow = new TableRow({
    children: [
      createHeaderCell("URL", 25),
      createHeaderCell("Score", 12),
      createHeaderCell("FCP", 12),
      createHeaderCell("LCP", 12),
      createHeaderCell("CLS", 11),
      createHeaderCell("TBT", 14),
      createHeaderCell("TTFB", 14)
    ]
  });

  const desktopRows = [desktopHeaderRow];
  results.forEach((item, index) => {
    const d = item.desktop;
    const shading = index % 2 === 0 ? null : zebraShading;
    const psiLink = item.pagespeedLink || ('https://pagespeed.web.dev/analysis?url=' + encodeURIComponent(item.url));
    desktopRows.push(new TableRow({
      children: [
        createCell(`${item.url}\nPageSpeed: ${psiLink}`, 25, false, shading),
        createScoreCell(`${d.performanceScore}`, 12, d.performanceScore, shading),
        createCell(d.fcp, 12, false, shading),
        createCell(d.lcp, 12, false, shading),
        createCell(d.cls, 11, false, shading),
        createCell(d.tbt, 14, false, shading),
        createCell(d.ttfb, 14, false, shading)
      ]
    }));
  });

  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: desktopRows
  }));

  // Section 3: Mobile Performance Analysis
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 150 },
      children: [
        new TextRun({ text: "3. Mobile Page Speed & Usability", bold: true, size: 28, color: "1E293B", font: "Segoe UI" })
      ]
    })
  );

  const mobileHeaderRow = new TableRow({
    children: [
      createHeaderCell("URL", 25),
      createHeaderCell("Mobile Score", 15),
      createHeaderCell("Mobile FCP", 15),
      createHeaderCell("Mobile LCP", 15),
      createHeaderCell("Mobile CLS", 15),
      createHeaderCell("Mobile Usability", 15)
    ]
  });

  const mobileRows = [mobileHeaderRow];
  results.forEach((item, index) => {
    const m = item.mobile;
    const s = item.seo;
    const shading = index % 2 === 0 ? null : zebraShading;
    const psiLink = item.pagespeedLink || ('https://pagespeed.web.dev/analysis?url=' + encodeURIComponent(item.url));
    mobileRows.push(new TableRow({
      children: [
        createCell(`${item.url}\nPageSpeed: ${psiLink}`, 25, false, shading),
        createScoreCell(`${m.performanceScore}`, 15, m.performanceScore, shading),
        createCell(m.fcp, 15, false, shading),
        createCell(m.lcp, 15, false, shading),
        createCell(m.cls, 15, false, shading),
        createCell(s.technical.hasViewport ? "Pass (Responsive)" : "Fail (No Viewport)", 15, true, shading)
      ]
    }));
  });

  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: mobileRows
  }));

  // Section 4: SEO Semrush Report
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 150 },
      children: [
        new TextRun({ text: "4. SEO Semrush-Style Technical Audit", bold: true, size: 28, color: "1E293B", font: "Segoe UI" })
      ]
    })
  );

  const seoHeaderRow = new TableRow({
    children: [
      createHeaderCell("URL", 22),
      createHeaderCell("Title & Meta Status", 24),
      createHeaderCell("Headings", 16),
      createHeaderCell("Images & Alt", 14),
      createHeaderCell("Technical & Schema", 24)
    ]
  });

  const seoRows = [seoHeaderRow];
  results.forEach((item, index) => {
    const s = item.seo;
    const shading = index % 2 === 0 ? null : zebraShading;
    const titleMetaStr = `Title: ${s.meta.titleStatus} (${s.meta.titleLength} ch)\nDesc: ${s.meta.descriptionStatus} (${s.meta.descriptionLength} ch)`;
    const headingStr = `H1s: ${s.headings.h1Count}\nH2s: ${s.headings.h2Count}`;
    const imgStr = `Total: ${s.images.total}\nMissing Alt: ${s.images.missingAlt}`;
    const techStr = `HTTPS: ${s.technical.isHttps ? 'Yes' : 'No'}\nRobots: ${s.technical.robotsTxtFound ? 'Yes' : 'No'}\nSchema: ${s.technical.hasSchema ? 'Yes' : 'No'}`;

    seoRows.push(new TableRow({
      children: [
        createCell(item.url, 22, false, shading),
        createCell(titleMetaStr, 24, false, shading),
        createCell(headingStr, 16, false, shading),
        createCell(imgStr, 14, false, shading),
        createCell(techStr, 24, false, shading)
      ]
    }));
  });

  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: seoRows
  }));

  // Section 5: AEO (Answer Engine Optimization) & AI Search Audit
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 150 },
      children: [
        new TextRun({ text: "5. AEO (Answer Engine Optimization) & AI Search Audit", bold: true, size: 28, color: "1E293B", font: "Segoe UI" })
      ]
    }),
    new Paragraph({
      spacing: { after: 200 },
      children: [
        new TextRun({
          text: "Evaluates readiness for Google AI Overviews, ChatGPT Search, Perplexity AI, Claude, and Gemini. Measures structured data (FAQPage, Speakable), Q&A chunking, AI bot crawler access, and EEAT authority signals.",
          size: 20,
          color: "475569",
          font: "Segoe UI"
        })
      ]
    })
  );

  const aeoHeaderRow = new TableRow({
    children: [
      createHeaderCell("URL", 22),
      createHeaderCell("AEO Score & Grade", 20),
      createHeaderCell("AI Schemas (FAQ/Voice)", 22),
      createHeaderCell("Q&A & 40-60w Answers", 18),
      createHeaderCell("AI Bots (GPT/Perplexity)", 18)
    ]
  });

  const aeoRows = [aeoHeaderRow];
  results.forEach((item, index) => {
    const a = item.aeo || {};
    const shading = index % 2 === 0 ? null : zebraShading;
    const scoreStr = `${a.aeoScore || 50} / 100\nGrade: ${a.readinessGrade || 'Standard'}`;
    const schemaStr = `FAQPage: ${a.schemas?.hasFaqSchema ? '✓ Found' : '✗ Missing'}\nSpeakable: ${a.schemas?.hasSpeakableSchema ? '✓ Voice Ready' : '✗ Missing'}`;
    const qaStr = `Questions: ${a.qaAnalysis?.totalQuestions || 0}\nOptimal 40-60w: ${a.summary?.optimalAnswersCount || 0}`;
    const botStr = `Allowed: ${a.summary?.aiBotsAllowedCount || 10}/${a.summary?.totalAiBotsCount || 10}\nBlocked: ${a.summary?.aiBotsBlockedCount || 0}\nllms.txt: ${a.summary?.llmsTxtFound ? 'Yes' : 'No'}`;

    aeoRows.push(new TableRow({
      children: [
        createCell(item.url, 22, false, shading),
        createScoreCell(scoreStr, 20, a.aeoScore || 50, shading),
        createCell(schemaStr, 22, false, shading),
        createCell(qaStr, 18, false, shading),
        createCell(botStr, 18, false, shading)
      ]
    }));
  });

  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: aeoRows
  }));

  // Section 6: What Need To Change (Suggestions & Action Plan)
  children.push(
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 150 },
      children: [
        new TextRun({ text: "6. Remediation Plan: What Needs To Change", bold: true, size: 28, color: "1E293B", font: "Segoe UI" })
      ]
    }),
    new Paragraph({
      spacing: { after: 200 },
      children: [
        new TextRun({
          text: "The table below lists all critical fixes, warnings, and optimization opportunities detected during the audit, categorized with clear instructions on how to remediate each item.",
          size: 20,
          color: "475569",
          font: "Segoe UI"
        })
      ]
    })
  );

  const sugHeaderRow = new TableRow({
    children: [
      createHeaderCell("Priority", 12),
      createHeaderCell("Category", 18),
      createHeaderCell("Issue Detected", 25),
      createHeaderCell("What Needs To Change (Fix Steps)", 45)
    ]
  });

  const sugRows = [sugHeaderRow];
  results.forEach((item) => {
    (item.suggestions || []).forEach((sug, index) => {
      const shading = index % 2 === 0 ? null : zebraShading;
      const recText = sug.codeSnippet 
        ? `${sug.recommendation}\n\n[Code Fix / Configuration]:\n${sug.codeSnippet}\n\nImpact: ${sug.impact}`
        : `${sug.recommendation}\n\nImpact: ${sug.impact}`;

      sugRows.push(new TableRow({
        children: [
          createPriorityCell(sug.priority, 12, shading),
          createCell(sug.category, 18, true, shading),
          createCell(`${sug.issue}\nFinding: ${sug.currentStatus}`, 25, false, shading),
          createCell(recText, 45, false, shading)
        ]
      }));
    });
  });

  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: sugRows
  }));

  const doc = new Document({
    sections: [{
      properties: {},
      children
    }]
  });

  return await Packer.toBuffer(doc);
}

function createHeaderCell(text, widthPercent) {
  return new TableCell({
    width: { size: widthPercent, type: WidthType.PERCENTAGE },
    shading: { fill: "1E293B" },
    margins: { top: 120, bottom: 120, left: 140, right: 140 },
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({
            text,
            bold: true,
            color: "FFFFFF",
            size: 19,
            font: "Segoe UI"
          })
        ]
      })
    ]
  });
}

function createCell(text, widthPercent, isBold = false, shading = null) {
  const paragraphs = String(text).split('\n').map(line => 
    new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { after: 50 },
      children: [
        new TextRun({
          text: line,
          bold: isBold,
          size: 18,
          color: "1E293B",
          font: "Segoe UI"
        })
      ]
    })
  );

  return new TableCell({
    width: { size: widthPercent, type: WidthType.PERCENTAGE },
    shading: shading || undefined,
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: paragraphs
  });
}

function createScoreCell(text, widthPercent, score, shading = null) {
  let color = "166534"; // green
  if (score < 50) color = "991B1B"; // red
  else if (score < 90) color = "92400E"; // orange

  return new TableCell({
    width: { size: widthPercent, type: WidthType.PERCENTAGE },
    shading: shading || undefined,
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({
            text,
            bold: true,
            size: 19,
            color,
            font: "Segoe UI"
          })
        ]
      })
    ]
  });
}

function createPriorityCell(priority, widthPercent, shading = null) {
  let color = "075985";
  if (priority === 'Critical') color = "991B1B";
  else if (priority === 'Warning') color = "92400E";

  return new TableCell({
    width: { size: widthPercent, type: WidthType.PERCENTAGE },
    shading: shading || undefined,
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({
            text: priority,
            bold: true,
            size: 19,
            color,
            font: "Segoe UI"
          })
        ]
      })
    ]
  });
}

module.exports = {
  generateDocxReport
};
