const ExcelJS = require('exceljs');

/**
 * Creates an Excel workbook with the 4 required tabs:
 * 1. Desktop Page Speed
 * 2. Mobile Page Speed
 * 3. SEO Semrush Report
 * 4. Suggestions (What Needs To Change)
 */
async function generateExcelReport(results) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Page Speed Report & SEO Semrush Analyzer';
  workbook.created = new Date();

  // Helper styles
  const headerFill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF1E293B' } // Slate 800
  };
  const headerFont = {
    name: 'Segoe UI',
    size: 11,
    bold: true,
    color: { argb: 'FFFFFFFF' }
  };
  const bodyFont = {
    name: 'Segoe UI',
    size: 10
  };
  const thinBorder = {
    top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
    left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
    bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
    right: { style: 'thin', color: { argb: 'FFE2E8F0' } }
  };

  // ----------------------------------------------------
  // TAB 1: Desktop Page Speed
  // ----------------------------------------------------
  const sheetDesktop = workbook.addWorksheet('Desktop Page Speed', {
    views: [{ state: 'frozen', ySplit: 1 }]
  });

  sheetDesktop.columns = [
    { header: 'URL', key: 'url', width: 35 },
    { header: 'Official PageSpeed.web.dev Link', key: 'pagespeedLink', width: 45 },
    { header: 'Perf Score', key: 'perf', width: 14 },
    { header: 'FCP (s)', key: 'fcp', width: 14 },
    { header: 'LCP (s)', key: 'lcp', width: 14 },
    { header: 'CLS', key: 'cls', width: 12 },
    { header: 'TBT (ms)', key: 'tbt', width: 14 },
    { header: 'Speed Index', key: 'speedIndex', width: 15 },
    { header: 'TTFB (ms)', key: 'ttfb', width: 14 },
    { header: 'A11y Score', key: 'a11y', width: 14 },
    { header: 'Best Practices', key: 'bestPractices', width: 15 },
    { header: 'Page Size (KB)', key: 'size', width: 16 },
    { header: 'Requests Count', key: 'requests', width: 16 },
    { header: 'Key Diagnostics / Bottlenecks', key: 'diagnostics', width: 45 }
  ];

  results.forEach(item => {
    const d = item.desktop;
    const diagStr = (d.diagnostics || []).map(x => `• ${x.title} (${x.savings})`).join('\n') || 'None detected';
    
    const row = sheetDesktop.addRow({
      url: item.url,
      pagespeedLink: item.pagespeedLink || `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(item.url)}`,
      perf: d.performanceScore,
      fcp: d.fcp,
      lcp: d.lcp,
      cls: d.cls,
      tbt: d.tbt,
      speedIndex: d.speedIndex,
      ttfb: d.ttfb,
      a11y: d.accessibilityScore,
      bestPractices: d.bestPracticesScore,
      size: d.pageSizeKb,
      requests: d.requestsCount,
      diagnostics: diagStr
    });

    // Colorize score cell
    const scoreCell = row.getCell('perf');
    applyScoreStyle(scoreCell, d.performanceScore);
  });

  formatSheet(sheetDesktop, headerFill, headerFont, bodyFont, thinBorder);

  // ----------------------------------------------------
  // TAB 2: Mobile Page Speed
  // ----------------------------------------------------
  const sheetMobile = workbook.addWorksheet('Mobile Page Speed', {
    views: [{ state: 'frozen', ySplit: 1 }]
  });

  sheetMobile.columns = [
    { header: 'URL', key: 'url', width: 35 },
    { header: 'Official PageSpeed.web.dev Link', key: 'pagespeedLink', width: 45 },
    { header: 'Mobile Score', key: 'perf', width: 15 },
    { header: 'FCP (s)', key: 'fcp', width: 14 },
    { header: 'LCP (s)', key: 'lcp', width: 14 },
    { header: 'CLS', key: 'cls', width: 12 },
    { header: 'TBT (ms)', key: 'tbt', width: 14 },
    { header: 'Speed Index', key: 'speedIndex', width: 15 },
    { header: 'TTFB (ms)', key: 'ttfb', width: 14 },
    { header: 'Mobile Usability', key: 'usability', width: 18 },
    { header: 'Viewport Tag', key: 'viewport', width: 16 },
    { header: 'Page Size (KB)', key: 'size', width: 16 },
    { header: 'Key Mobile Bottlenecks', key: 'diagnostics', width: 45 }
  ];

  results.forEach(item => {
    const m = item.mobile;
    const s = item.seo;
    const diagStr = (m.diagnostics || []).map(x => `• ${x.title} (${x.savings})`).join('\n') || 'None detected';
    
    const row = sheetMobile.addRow({
      url: item.url,
      pagespeedLink: item.pagespeedLink || `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(item.url)}`,
      perf: m.performanceScore,
      fcp: m.fcp,
      lcp: m.lcp,
      cls: m.cls,
      tbt: m.tbt,
      speedIndex: m.speedIndex,
      ttfb: m.ttfb,
      usability: s.technical.hasViewport ? 'Pass (Responsive)' : 'Fail (No Viewport)',
      viewport: s.technical.hasViewport ? 'Present' : 'Missing',
      size: m.pageSizeKb,
      diagnostics: diagStr
    });

    const scoreCell = row.getCell('perf');
    applyScoreStyle(scoreCell, m.performanceScore);

    const usabilityCell = row.getCell('usability');
    if (!s.technical.hasViewport) {
      usabilityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
      usabilityCell.font = { color: { argb: 'FF991B1B' }, bold: true };
    } else {
      usabilityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCFCE7' } };
      usabilityCell.font = { color: { argb: 'FF166534' }, bold: true };
    }
  });

  formatSheet(sheetMobile, headerFill, headerFont, bodyFont, thinBorder);

  // ----------------------------------------------------
  // TAB 3: SEO Semrush Report (Enterprise 360° Matrix)
  // ----------------------------------------------------
  const sheetSeo = workbook.addWorksheet('SEO Semrush Report', {
    views: [{ state: 'frozen', ySplit: 1 }]
  });

  sheetSeo.columns = [
    { header: 'URL', key: 'url', width: 35 },
    { header: 'SEO Health Score', key: 'score', width: 18 },
    { header: 'HTTP Status', key: 'httpStatus', width: 14 },
    { header: 'Title Tag', key: 'title', width: 35 },
    { header: 'Title Length', key: 'titleLen', width: 14 },
    { header: 'Title Status', key: 'titleStat', width: 14 },
    { header: 'Meta Description', key: 'desc', width: 40 },
    { header: 'Desc Length', key: 'descLen', width: 14 },
    { header: 'Desc Status', key: 'descStat', width: 14 },
    { header: 'Primary H1 Tag', key: 'h1', width: 35 },
    { header: 'H1 Count', key: 'h1Count', width: 12 },
    { header: 'H2 Count', key: 'h2Count', width: 12 },
    { header: 'Heading Hierarchy', key: 'headingSkips', width: 18 },
    { header: 'Canonical Tag', key: 'canonical', width: 30 },
    { header: 'Canonical Status', key: 'canonicalStat', width: 18 },
    { header: 'Robots Directives', key: 'robotsDirectives', width: 22 },
    { header: 'Robots.txt', key: 'robots', width: 14 },
    { header: 'XML Sitemap', key: 'sitemap', width: 14 },
    { header: 'Total Images', key: 'images', width: 14 },
    { header: 'Missing ALT', key: 'missingAlt', width: 14 },
    { header: 'Missing Dimensions (CLS Risk)', key: 'missingDims', width: 22 },
    { header: 'Next-Gen Images', key: 'nextGen', width: 16 },
    { header: 'Internal Links', key: 'internalLinks', width: 15 },
    { header: 'External Links', key: 'externalLinks', width: 15 },
    { header: 'Insecure Links', key: 'insecureLinks', width: 16 },
    { header: 'Schema.org Types', key: 'schema', width: 24 },
    { header: 'Open Graph (OG)', key: 'og', width: 16 },
    { header: 'Twitter Card', key: 'twitter', width: 16 },
    { header: 'HTTPS Secure', key: 'https', width: 15 },
    { header: 'HSTS Header', key: 'hsts', width: 15 },
    { header: 'Mixed Content', key: 'mixedContent', width: 16 },
    { header: 'Mobile Viewport', key: 'viewport', width: 16 },
    { header: 'HTML Lang', key: 'lang', width: 12 },
    { header: 'Word Count', key: 'wordCount', width: 14 },
    { header: 'Text/HTML Ratio', key: 'ratio', width: 16 }
  ];

  results.forEach(item => {
    const s = item.seo;
    const row = sheetSeo.addRow({
      url: item.url,
      score: s.healthScore,
      httpStatus: s.statusCode,
      title: s.meta.title,
      titleLen: s.meta.titleLength,
      titleStat: s.meta.titleStatus,
      desc: s.meta.description,
      descLen: s.meta.descriptionLength,
      descStat: s.meta.descriptionStatus,
      h1: s.headings.primaryH1,
      h1Count: s.headings.h1Count,
      h2Count: s.headings.h2Count,
      headingSkips: s.headings.hasHeadingSkips ? 'Skipped Levels' : 'Clean Hierarchy',
      canonical: s.meta.canonical,
      canonicalStat: s.meta.isSelfCanonical ? 'Self-Canonical' : (s.meta.isCrossDomainCanonical ? 'Cross-Domain' : (s.meta.canonical !== '(None)' ? 'Custom' : 'Missing')),
      robotsDirectives: s.meta.robots,
      robots: s.technical.robotsTxtFound ? 'Found' : 'Missing',
      sitemap: s.technical.sitemapFound ? 'Found' : 'Missing',
      images: s.images.total,
      missingAlt: s.images.missingAlt,
      missingDims: s.images.missingDimensions || 0,
      nextGen: s.images.nextGenFormats || 0,
      internalLinks: s.links.internal,
      externalLinks: s.links.external,
      insecureLinks: s.links.insecureInternalLinks || 0,
      schema: s.technical.hasSchema ? (s.technical.schemaTypes.join(', ') || 'Detected') : 'None',
      og: s.social.isComplete ? 'Complete' : 'Incomplete',
      twitter: s.social.hasTwitterCard ? 'Configured' : 'Missing',
      https: s.technical.isHttps ? 'Yes (Secure)' : 'No (Insecure)',
      hsts: s.technical.hasHsts ? 'Enabled' : 'Missing',
      mixedContent: (s.technical.mixedContentCount || 0) > 0 ? `${s.technical.mixedContentCount} Insecure Assets` : 'Clean (No Mixed Content)',
      viewport: s.technical.hasViewport ? 'Responsive' : 'Missing',
      lang: s.technical.htmlLang,
      wordCount: s.content.wordCount,
      ratio: s.content.textHtmlRatio
    });

    const scoreCell = row.getCell('score');
    applyScoreStyle(scoreCell, s.healthScore);

    const missingAltCell = row.getCell('missingAlt');
    if (s.images.missingAlt > 0) {
      missingAltCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF3C7' } };
      missingAltCell.font = { color: { argb: 'FF92400E' }, bold: true };
    }

    const httpsCell = row.getCell('https');
    if (!s.technical.isHttps) {
      httpsCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
      httpsCell.font = { color: { argb: 'FF991B1B' }, bold: true };
    }
  });

  formatSheet(sheetSeo, headerFill, headerFont, bodyFont, thinBorder);

  // ----------------------------------------------------
  // TAB 4: AEO (Answer Engine Optimization) Report (10+ Years Standard)
  // ----------------------------------------------------
  const sheetAeo = workbook.addWorksheet('AEO AI Search Report', {
    views: [{ state: 'frozen', ySplit: 1 }]
  });

  sheetAeo.columns = [
    { header: 'URL', key: 'url', width: 35 },
    { header: 'AEO Score', key: 'score', width: 14 },
    { header: 'AI Grade', key: 'grade', width: 22 },
    { header: 'AI Crawlers Allowed', key: 'aiBots', width: 20 },
    { header: 'AI Bots Blocked', key: 'blockedBots', width: 22 },
    { header: '/llms.txt Standard', key: 'llmsTxt', width: 18 },
    { header: 'FAQPage Schema', key: 'faqSchema', width: 18 },
    { header: 'Speakable Schema', key: 'speakable', width: 18 },
    { header: 'sameAs Entity Links', key: 'sameAs', width: 22 },
    { header: 'Q&A Headings', key: 'qaCount', width: 16 },
    { header: 'Optimal Answers (40-60w)', key: 'optimalAnswers', width: 24 },
    { header: 'Comparison Tables', key: 'tables', width: 18 },
    { header: 'Step Lists for AI', key: 'lists', width: 18 },
    { header: 'EEAT Author Byline', key: 'author', width: 18 },
    { header: 'Authority Citations (.edu/gov/wiki)', key: 'authorityCitations', width: 26 },
    { header: 'Fact / Metric Density', key: 'factDensity', width: 20 },
    { header: 'Flesch Readability', key: 'readability', width: 18 },
    { header: 'Reading Grade', key: 'readabilityGrade', width: 24 },
    { header: 'Avg Words Per Sentence', key: 'avgSentence', width: 22 }
  ];

  results.forEach(item => {
    const a = item.aeo || {
      aeoScore: 50,
      readinessGrade: 'Unanalyzed',
      summary: {},
      schemas: {},
      qaAnalysis: {},
      scannability: {},
      eeat: {},
      readability: {}
    };

    const blockedList = (a.aiBotStatus || []).filter(b => !b.allowed).map(b => b.bot).join(', ') || 'None (All Allowed)';

    const row = sheetAeo.addRow({
      url: item.url,
      score: a.aeoScore || 0,
      grade: a.readinessGrade || 'N/A',
      aiBots: `${a.summary?.aiBotsAllowedCount || 10} / ${a.summary?.totalAiBotsCount || 10} Allowed`,
      blockedBots: blockedList,
      llmsTxt: a.summary?.llmsTxtFound ? 'Present (/llms.txt)' : 'Missing',
      faqSchema: a.schemas?.hasFaqSchema ? 'Found (Optimized)' : 'Missing',
      speakable: a.schemas?.hasSpeakableSchema ? 'Found (Voice Ready)' : 'Missing',
      sameAs: a.schemas?.hasSameAs ? 'Verified Knowledge Graph Links' : 'Missing',
      qaCount: a.qaAnalysis?.totalQuestions || 0,
      optimalAnswers: `${a.summary?.optimalAnswersCount || 0} chunks`,
      tables: a.scannability?.tablesCount || 0,
      lists: (a.scannability?.bulletListsCount || 0) + (a.scannability?.numberedListsCount || 0),
      author: a.eeat?.hasAuthorByline ? 'Present (Verified)' : 'Missing',
      authorityCitations: `${a.eeat?.authorityCitationCount || 0} Outbound Authority Links`,
      factDensity: `${a.eeat?.statCount || 0} Metrics / Data Points`,
      readability: a.readability?.score || 70,
      readabilityGrade: a.readability?.grade || 'Standard',
      avgSentence: `${a.readability?.avgWordsPerSentence || 15} words/sent`
    });

    const aeoScoreCell = row.getCell('score');
    applyScoreStyle(aeoScoreCell, a.aeoScore || 0);

    const faqCell = row.getCell('faqSchema');
    if (!a.schemas?.hasFaqSchema) {
      faqCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF3C7' } };
      faqCell.font = { color: { argb: 'FF92400E' }, bold: true };
    } else {
      faqCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCFCE7' } };
      faqCell.font = { color: { argb: 'FF166534' }, bold: true };
    }
  });

  formatSheet(sheetAeo, headerFill, headerFont, bodyFont, thinBorder);

  // ----------------------------------------------------
  // TAB 5: What Need To Change (Actionable Suggestions)
  // ----------------------------------------------------
  const sheetSuggestions = workbook.addWorksheet('What Need To Change', {
    views: [{ state: 'frozen', ySplit: 1 }]
  });

  sheetSuggestions.columns = [
    { header: 'Priority', key: 'priority', width: 14 },
    { header: 'Category', key: 'category', width: 22 },
    { header: 'URL', key: 'url', width: 35 },
    { header: 'Issue Detected', key: 'issue', width: 32 },
    { header: 'Current Finding', key: 'current', width: 32 },
    { header: 'Actionable Recommendation (What To Fix)', key: 'recommendation', width: 55 },
    { header: 'Estimated Impact', key: 'impact', width: 38 }
  ];

  results.forEach(item => {
    (item.suggestions || []).forEach(sug => {
      const recText = sug.codeSnippet ? `${sug.recommendation}\n\n[Code Fix / Configuration]:\n${sug.codeSnippet}` : sug.recommendation;
      const row = sheetSuggestions.addRow({
        priority: sug.priority,
        category: sug.category,
        url: sug.url,
        issue: sug.issue,
        current: sug.currentStatus,
        recommendation: recText,
        impact: sug.impact
      });

      const priorityCell = row.getCell('priority');
      if (sug.priority === 'Critical') {
        priorityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
        priorityCell.font = { color: { argb: 'FF991B1B' }, bold: true };
      } else if (sug.priority === 'Warning') {
        priorityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF3C7' } };
        priorityCell.font = { color: { argb: 'FF92400E' }, bold: true };
      } else {
        priorityCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0F2FE' } };
        priorityCell.font = { color: { argb: 'FF075985' }, bold: true };
      }
    });
  });

  formatSheet(sheetSuggestions, headerFill, headerFont, bodyFont, thinBorder);

  return workbook.xlsx.writeBuffer();
}

function applyScoreStyle(cell, score) {
  cell.alignment = { horizontal: 'center' };
  if (score >= 90) {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCFCE7' } };
    cell.font = { color: { argb: 'FF166534' }, bold: true };
  } else if (score >= 50) {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF3C7' } };
    cell.font = { color: { argb: 'FF92400E' }, bold: true };
  } else {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
    cell.font = { color: { argb: 'FF991B1B' }, bold: true };
  }
}

function formatSheet(sheet, headerFill, headerFont, bodyFont, border) {
  // Format header row
  const headerRow = sheet.getRow(1);
  headerRow.height = 26;
  headerRow.eachCell(cell => {
    cell.fill = headerFill;
    cell.font = headerFont;
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.border = border;
  });

  // Format data rows
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    row.height = 24;
    row.eachCell(cell => {
      if (!cell.font) cell.font = bodyFont;
      cell.border = border;
      cell.alignment = Object.assign({ vertical: 'middle', wrapText: true }, cell.alignment || {});
    });
  });

  // Enable auto filter
  sheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: sheet.columns.length }
  };
}

module.exports = {
  generateExcelReport
};
