const express = require('express');
const cors = require('cors');
const path = require('path');
const { getPageSpeed } = require('./analyzer/pagespeed');
const { auditSEO } = require('./analyzer/seo');
const { auditAEO } = require('./analyzer/aeo');
const { generateSuggestions } = require('./analyzer/suggestions');
const { generateExcelReport } = require('./generators/excel');
const { generateDocxReport } = require('./generators/docx');
const { auditBrokenLinks, generateBrokenLinksExcel } = require('./analyzer/brokenLinks');
const { validateSafeUrl, sanitizeBatchUrls } = require('./analyzer/security');

const app = express();
let PORT = parseInt(process.env.PORT, 10) || 3050;

// Security hardening: hide server framework
app.disable('x-powered-by');

// Security hardening: standard defensive HTTP response headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

app.use(cors());
// Request body ceiling (15mb is ample for 2,000+ URLs while preventing payload flooding DoS)
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Serve static frontend UI
app.use(express.static(path.join(__dirname, 'public')));

/**
 * Health check
 */
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', name: 'Page Speed Report & SEO Semrush Analyzer' });
});

/**
 * REAL-TIME Streaming Analyze via Server-Sent Events (SSE)
 * Each URL result is pushed as soon as it's ready.
 *
 * FIX: For large URL batches (100+ URLs), the old GET ?urls=... approach
 * hit URL length limits. We now accept URLs via POST body for the stream endpoint.
 * POST /api/stream  body: { urls: [...], apiKey: '...' }
 */
app.post('/api/stream', async (req, res) => {
  const { urls: bodyUrls = [], apiKey = '' } = req.body;

  const rawUrlList = Array.isArray(bodyUrls) ? bodyUrls : String(bodyUrls).split('\n');
  const { validUrls: cleanUrls, rejected } = sanitizeBatchUrls(rawUrlList, 1000);

  if (cleanUrls.length === 0) {
    const errorMsg = rejected.length > 0
      ? `Validation failed: ${rejected[0].reason}`
      : 'No valid URLs provided.';
    return res.status(400).json({ error: errorMsg, rejected });
  }

  // SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  // Keep Express from closing the socket on timeout for large batches
  res.setTimeout(0);
  if (req.socket) req.socket.setTimeout(0);
  res.flushHeaders();

  // Heartbeat every 20s to prevent proxy/browser killing idle SSE connections
  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(': heartbeat\n\n');
  }, 20000);

  const send = (event, data) => {
    if (!res.writableEnded) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  const cleanup = () => { clearInterval(heartbeat); };
  res.on('close', cleanup);
  res.on('finish', cleanup);

  send('start', { total: cleanUrls.length, timestamp: new Date().toISOString() });

  // High-performance worker pool for 500+ / 1000+ URL scale
  const CONCURRENCY = Math.min(5, Math.max(2, Math.min(6, Math.ceil(cleanUrls.length / 8))));
  let nextIndex = 0;
  let doneCount = 0;

  async function worker() {
    while (nextIndex < cleanUrls.length) {
      if (res.writableEnded) break;
      const idx = nextIndex++;
      const url = cleanUrls[idx];
      send('progress', { url, index: idx, total: cleanUrls.length, status: 'analyzing' });

      try {
        const urlTimeout = new Promise((_, rej) =>
          setTimeout(() => rej(new Error('URL analysis timed out after 50s')), 50000)
        );

        const analyse = async () => {
          // 1. Fetch SEO first (reuses domain-level cache for robots.txt & sitemap.xml)
          const seoData = await auditSEO(url);
          const targetUrl = seoData.finalUrl || url;

          // 2. Reuse HTML and robots.txt for AEO & PageSpeed (saves 70% of network requests)
          const [aeoData, desktopData, mobileData] = await Promise.all([
            auditAEO(targetUrl, seoData.rawHtml, seoData.robotsTxtContent, seoData.technical?.llmsTxtFound),
            getPageSpeed(targetUrl, 'desktop', apiKey),
            getPageSpeed(targetUrl, 'mobile', apiKey)
          ]);

          // Prevent Node heap memory buildup on 1000+ URLs by deleting raw HTML string
          delete seoData.rawHtml;
          delete seoData.robotsTxtContent;

          const suggestions = generateSuggestions(targetUrl, desktopData, mobileData, seoData, aeoData);
          return { desktopData, mobileData, targetUrl, seoData, aeoData, suggestions };
        };

        const { desktopData, mobileData, targetUrl, seoData, aeoData, suggestions } =
          await Promise.race([analyse(), urlTimeout]);

        const result = {
          url: targetUrl,
          originalInput: url,
          pagespeedLink: desktopData.pagespeedLink || mobileData.pagespeedLink || `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(targetUrl)}`,
          timestamp: new Date().toISOString(),
          desktop: desktopData,
          mobile:  mobileData,
          seo:     seoData,
          aeo:     aeoData,
          suggestions
        };

        doneCount++;
        send('result', { index: idx, result, doneCount, total: cleanUrls.length });
        console.log(`[SSE ${doneCount}/${cleanUrls.length}] Done → ${targetUrl} | D:${desktopData.performanceScore} M:${mobileData.performanceScore} SEO:${seoData.healthScore} AEO:${aeoData.aeoScore}`);
      } catch (err) {
        doneCount++;
        send('error', { url, index: idx, message: err.message || 'Unknown error', doneCount, total: cleanUrls.length });
        console.error(`[SSE ${doneCount}/${cleanUrls.length}] Error → ${url}: ${err.message}`);
      }
    }
  }

  const workers = Array.from({ length: Math.min(CONCURRENCY, cleanUrls.length) }, () => worker());
  await Promise.all(workers);

  send('done', { total: cleanUrls.length, timestamp: new Date().toISOString() });
  cleanup();
  res.end();
});

/**
 * Analyze multiple URLs (POST) — kept for export use
 */
app.post('/api/analyze', async (req, res) => {
  const { urls, apiKey } = req.body;
  if (!urls || !Array.isArray(urls) || urls.length === 0) {
    return res.status(400).json({ error: 'Please provide at least one valid URL.' });
  }

  const { validUrls: cleanUrls, rejected } = sanitizeBatchUrls(urls, 500);

  if (cleanUrls.length === 0) {
    const errorMsg = rejected.length > 0
      ? `Validation failed: ${rejected[0].reason}`
      : 'No valid URLs provided.';
    return res.status(400).json({ error: errorMsg, rejected });
  }

  try {
    const results = [];
    for (const url of cleanUrls) {
      const [desktopData, mobileData] = await Promise.all([
        getPageSpeed(url, 'desktop', apiKey || ''),
        getPageSpeed(url, 'mobile',  apiKey || '')
      ]);
      const targetUrl = desktopData.targetUrl || mobileData.targetUrl || url;
      const seoData = await auditSEO(targetUrl);
      const aeoData = await auditAEO(targetUrl, seoData.rawHtml, seoData.robotsTxtContent, seoData.technical?.llmsTxtFound);
      const suggestions = generateSuggestions(targetUrl, desktopData, mobileData, seoData, aeoData);
      results.push({
        url: targetUrl,
        originalInput: url,
        pagespeedLink: desktopData.pagespeedLink || mobileData.pagespeedLink || `https://pagespeed.web.dev/analysis?url=${encodeURIComponent(targetUrl)}`,
        timestamp: new Date().toISOString(),
        desktop: desktopData,
        mobile: mobileData,
        seo: seoData,
        aeo: aeoData,
        suggestions
      });
    }
    res.json({ success: true, count: results.length, results });
  } catch (err) {
    console.error('Analysis error:', err);
    res.status(500).json({ error: err.message || 'Error occurred while analyzing URLs' });
  }
});

/**
 * Export 4-tab Excel file (.xlsx)
 */
app.post('/api/export/excel', async (req, res) => {
  const { results } = req.body;
  if (!results || !Array.isArray(results) || results.length === 0) {
    return res.status(400).json({ error: 'No results data provided for Excel export.' });
  }

  try {
    const buffer = await generateExcelReport(results);
    const filename = `PageSpeed_SEO_Semrush_Report_${Date.now()}.xlsx`;
    
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  } catch (err) {
    console.error('Excel generation error:', err);
    res.status(500).json({ error: 'Failed to generate Excel file: ' + err.message });
  }
});

/**
 * Export Word Document file (.docx)
 */
app.post('/api/export/docx', async (req, res) => {
  const { results } = req.body;
  if (!results || !Array.isArray(results) || results.length === 0) {
    return res.status(400).json({ error: 'No results data provided for Document export.' });
  }

  try {
    const buffer = await generateDocxReport(results);
    const filename = `PageSpeed_SEO_Audit_Report_${Date.now()}.docx`;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  } catch (err) {
    console.error('Document generation error:', err);
    res.status(500).json({ error: 'Failed to generate Document file: ' + err.message });
  }
});

/**
 * REAL-TIME Streaming Broken Link Checker via Server-Sent Events (SSE)
 * POST /api/broken-links/stream  body: { target, mode, maxPages, checkExternal, urls: [...] }
 * Also accepts GET for small URL lists (backward compat)
 */
async function handleBrokenLinksStream(req, res) {
  const body = req.method === 'POST' ? req.body : {};
  const mode = (body.mode || req.query.mode || 'site') === 'urls' ? 'urls' : 'site';
  const target = ((body.target || req.query.target) || '').trim();
  const maxPages = Math.min(Math.max(parseInt(body.maxPages || req.query.maxPages, 10) || 25, 1), 100);
  const checkExternal = (body.checkExternal !== false) && (req.query.checkExternal !== 'false');

  // Support URLs from POST body (array or newline-joined string)
  let rawUrls = [];
  if (body.urls) {
    rawUrls = Array.isArray(body.urls)
      ? body.urls
      : String(body.urls).split(/[\n,]/).map(u => u.trim()).filter(Boolean);
  } else if (req.query.urls) {
    rawUrls = String(req.query.urls).split(',').map(u => u.trim()).filter(Boolean);
  }

  if (!target && rawUrls.length === 0) {
    return res.status(400).json({ error: 'Please provide a target domain or list of URLs.' });
  }

  // SSRF & Protocol Security Validation
  if (mode === 'site') {
    const checkTarget = validateSafeUrl(target);
    if (!checkTarget.safe) {
      return res.status(400).json({ error: `Security validation failed: ${checkTarget.error}` });
    }
  } else {
    const { validUrls, rejected } = sanitizeBatchUrls(rawUrls, 1000);
    if (validUrls.length === 0) {
      return res.status(400).json({ error: rejected[0]?.reason || 'No valid URLs provided.' });
    }
    rawUrls = validUrls;
  }

  // SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setTimeout(0);
  if (req.socket) req.socket.setTimeout(0);
  res.flushHeaders();

  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(': heartbeat\n\n');
  }, 20000);

  const send = (event, data) => {
    if (!res.writableEnded) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  const cleanup = () => clearInterval(heartbeat);
  res.on('close', cleanup);
  res.on('finish', cleanup);

  send('start', { mode, target: target || rawUrls[0], timestamp: new Date().toISOString() });

  try {
    const summary = await auditBrokenLinks({
      mode,
      target: target || rawUrls[0],
      rawUrls,
      maxPages,
      checkExternal,
      concurrency: 8,
      onProgress: (prog) => { send(prog.type, prog); }
    });

    send('complete', { summary });
    console.log(`[BrokenLinks] Done for ${target || rawUrls.length + ' URLs'}: Total ${summary.totalLinksChecked}, Broken ${summary.brokenCount}`);
  } catch (err) {
    console.error('[BrokenLinks] Error:', err);
    send('error', { message: err.message || 'Audit encountered an error' });
  }

  cleanup();
  res.end();
}

app.get('/api/broken-links/stream', handleBrokenLinksStream);
app.post('/api/broken-links/stream', handleBrokenLinksStream);

/**
 * Broken Link Audit JSON endpoint (POST)
 */
app.post('/api/broken-links/check', async (req, res) => {
  const { mode = 'site', target = '', urls = [], maxPages = 25, checkExternal = true } = req.body;
  if (!target && (!urls || urls.length === 0)) {
    return res.status(400).json({ error: 'Please provide target URL or URLs list' });
  }

  try {
    const summary = await auditBrokenLinks({
      mode,
      target,
      rawUrls: urls,
      maxPages: Math.min(Math.max(parseInt(maxPages, 10) || 25, 1), 100),
      checkExternal: checkExternal !== false,
      concurrency: 6
    });
    res.json({ success: true, summary });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Export Broken Links Excel report (.xlsx)
 */
app.post('/api/broken-links/export/excel', async (req, res) => {
  const { summary } = req.body;
  if (!summary || !summary.results || !Array.isArray(summary.results)) {
    return res.status(400).json({ error: 'No broken links audit data provided for Excel export.' });
  }

  try {
    const buffer = await generateBrokenLinksExcel(summary);
    const domain = (summary.target || 'site').replace(/https?:\/\/|\/|:/g, '_');
    const filename = `Broken_Links_Report_${domain}_${Date.now()}.xlsx`;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  } catch (err) {
    console.error('Broken links Excel export error:', err);
    res.status(500).json({ error: 'Failed to generate Excel report: ' + err.message });
  }
});

function startServer(portToTry) {
  const server = app.listen(portToTry, () => {
    console.log(`=======================================================`);
    console.log(`🚀 Page Speed Report & SEO Semrush Analyzer is RUNNING!`);
    console.log(`👉 Local Dashboard: http://localhost:${portToTry}`);
    console.log(`=======================================================`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`Port ${portToTry} is in use, trying port ${portToTry + 1}...`);
      startServer(portToTry + 1);
    } else {
      console.error('Server error:', err);
    }
  });
}

startServer(PORT);

