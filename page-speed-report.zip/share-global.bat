@echo off
title Page Speed Report - Global Live Tunnel
cd /d "%~dp0"
echo =========================================================
echo   Starting Page Speed & AEO Scraper on Public URL...
echo =========================================================
cloudflared tunnel --url http://localhost:3050
pause
