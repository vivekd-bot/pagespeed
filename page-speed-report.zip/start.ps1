# Page Speed Report & SEO Semrush Analyzer Launcher
Set-Location -Path $PSScriptRoot
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","User") + ";" + [System.Environment]::GetEnvironmentVariable("Path","Machine")
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "  Launching Page Speed Report & SEO Semrush Analyzer...  " -ForegroundColor Green
Write-Host "  Opening http://localhost:3050 in your browser...       " -ForegroundColor Yellow
Write-Host "=========================================================" -ForegroundColor Cyan
Start-Process "http://localhost:3050"
node server.js

